import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, MapPin, Utensils, Flag } from 'lucide-react';
import { State, Food, Language, translations } from '../data/malaysiaData';
import FoodCard from './FoodCard';

interface Props {
  state: State;
  language: Language;
  onBack: () => void;
  onFoodClick: (food: Food) => void;
}

export default function StatePanel({ state, language, onBack, onFoodClick }: Props) {
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const t = translations[language];

  const getStateName = () => {
    if (language === 'bm') return state.nameBM;
    if (language === 'zh') return state.nameZH;
    return state.name;
  };

  const getDescription = () => {
    if (language === 'bm') return state.descriptionBM;
    if (language === 'zh') return state.descriptionZH;
    return state.description;
  };

  const categories = ['All', ...new Set(state.foods.map(f => f.category))];
  const filteredFoods = activeCategory === 'All'
    ? state.foods
    : state.foods.filter(f => f.category === activeCategory);

  const halalCount = state.foods.filter(f => f.isHalal).length;
  const avgSpice = Math.round(state.foods.reduce((acc, f) => acc + f.spiceLevel, 0) / state.foods.length * 10) / 10;

  return (
    <div className="relative w-full h-screen overflow-hidden bg-[#05050d]">
      {/* Ambient background */}
      <div className="absolute inset-0">
        {/* State-colored ambient glow */}
        <motion.div
          className="absolute top-0 left-0 w-full h-full"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
          style={{
            background: `radial-gradient(ellipse at 25% 25%, ${state.accentColor}22, transparent 55%)`
          }}
        />
        <div
          className="absolute bottom-0 right-0 w-2/3 h-2/3"
          style={{ background: `radial-gradient(ellipse at 80% 80%, ${state.accentColor}12, transparent 60%)` }}
        />
        {/* Subtle batik grid */}
        <div className="absolute inset-0 opacity-[0.015]"
          style={{
            backgroundImage: `repeating-linear-gradient(45deg, ${state.accentColor} 0, ${state.accentColor} 1px, transparent 0, transparent 50%)`,
            backgroundSize: '20px 20px',
          }}
        />
      </div>

      {/* Top gradient fade */}
      <div className="absolute top-0 left-0 right-0 h-20 z-20 pointer-events-none"
        style={{ background: 'linear-gradient(to bottom, rgba(5,5,13,0.95), transparent)' }}
      />

      {/* Header */}
      <div className="absolute top-0 left-0 right-0 z-30 flex items-center justify-between px-6 py-5">
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          onClick={onBack}
          whileHover={{ x: -4 }}
          whileTap={{ scale: 0.95 }}
          className="flex items-center gap-2 px-3 py-2 rounded-xl transition-all group"
          style={{
            background: 'rgba(255,255,255,0.04)',
            border: '1px solid rgba(255,255,255,0.08)',
            backdropFilter: 'blur(10px)',
          }}
        >
          <ArrowLeft size={15} className="text-white/50 group-hover:text-amber-400 transition-colors" />
          <span className="text-white/50 group-hover:text-white/80 text-sm transition-colors">{t.backToMap}</span>
        </motion.button>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex items-center gap-2 px-3 py-1.5 rounded-full"
          style={{ background: `${state.accentColor}15`, border: `1px solid ${state.accentColor}30` }}
        >
          <motion.div
            className="w-2 h-2 rounded-full"
            style={{ background: state.accentColor }}
            animate={{ opacity: [0.5, 1, 0.5], scale: [1, 1.2, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
          <span className="text-xs font-medium" style={{ color: state.accentColor }}>
            {state.region === 'federal' ? 'Federal Territory' : state.region === 'east-malaysia' ? 'East Malaysia' : 'Peninsular'}
          </span>
        </motion.div>
      </div>

      {/* Main layout */}
      <div className="absolute inset-0 flex flex-col lg:flex-row overflow-hidden pt-16">
        {/* Left sidebar - State info */}
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.7, ease: 'easeOut' }}
          className="w-full lg:w-72 xl:w-80 flex-shrink-0 overflow-y-auto"
          style={{
            borderRight: `1px solid ${state.accentColor}18`,
            background: 'rgba(0,0,0,0.15)',
          }}
        >
          <div className="p-6 lg:p-8">
            {/* State symbol */}
            <div className="mb-6">
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.2, duration: 0.5 }}
                className="w-16 h-16 rounded-2xl mb-4 flex items-center justify-center relative"
                style={{
                  background: `linear-gradient(135deg, ${state.accentColor}25, ${state.accentColor}10)`,
                  border: `1px solid ${state.accentColor}35`,
                  boxShadow: `0 0 25px ${state.glowColor}, inset 0 1px 0 ${state.accentColor}20`,
                }}
              >
                <StateSymbol stateId={state.id} color={state.accentColor} />
                {/* Glow ring */}
                <div className="absolute inset-0 rounded-2xl opacity-30"
                  style={{ boxShadow: `0 0 20px ${state.accentColor}` }} />
              </motion.div>

              {/* State name */}
              <motion.h1
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="text-3xl xl:text-4xl font-bold text-white leading-tight mb-1"
                style={{
                  fontFamily: "'Playfair Display', serif",
                  textShadow: `0 0 25px ${state.glowColor}`,
                }}
              >
                {getStateName()}
              </motion.h1>

              {/* Capital */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.4 }}
                className="flex items-center gap-1.5"
              >
                <MapPin size={11} className="text-amber-400/60" />
                <span className="text-white/35 text-sm">{state.capital}</span>
              </motion.div>
            </div>

            {/* Divider */}
            <div className="h-px w-full mb-5"
              style={{ background: `linear-gradient(to right, ${state.accentColor}50, transparent)` }} />

            {/* Description */}
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="text-white/45 text-sm leading-relaxed mb-5"
            >
              {getDescription()}
            </motion.p>

            {/* Cultural theme card */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="rounded-xl p-3.5 mb-5"
              style={{
                background: `${state.accentColor}10`,
                border: `1px solid ${state.accentColor}22`,
              }}
            >
              <div className="flex items-center gap-2 mb-1.5">
                <Flag size={11} style={{ color: state.accentColor }} />
                <p className="text-white/30 text-xs uppercase tracking-wider">Cultural Theme</p>
              </div>
              <p className="text-white/65 text-sm italic leading-relaxed">{state.culturalTheme}</p>
            </motion.div>

            {/* Stats grid */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7 }}
              className="grid grid-cols-3 gap-2"
            >
              {[
                { label: t.foods, value: state.foods.length, color: state.accentColor },
                { label: t.halal, value: halalCount, color: '#22c55e' },
                { label: 'Avg Spice', value: avgSpice, color: '#f97316' },
              ].map(stat => (
                <div
                  key={stat.label}
                  className="rounded-xl p-3 text-center"
                  style={{
                    background: 'rgba(255,255,255,0.03)',
                    border: '1px solid rgba(255,255,255,0.06)',
                  }}
                >
                  <p className="text-xl font-bold" style={{ color: stat.color }}>{stat.value}</p>
                  <p className="text-white/25 text-xs mt-0.5">{stat.label}</p>
                </div>
              ))}
            </motion.div>
          </div>
        </motion.div>

        {/* Right content - Food grid */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Foods header with categories */}
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="flex-shrink-0 px-6 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
            style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}
          >
            <div>
              <div className="flex items-center gap-2">
                <Utensils size={14} style={{ color: state.accentColor }} />
                <h2 className="text-white font-bold text-lg">{t.famousFoods}</h2>
              </div>
              <p className="text-white/25 text-sm mt-0.5">
                {filteredFoods.length} {activeCategory === 'All' ? 'dishes' : activeCategory.toLowerCase()} to explore
              </p>
            </div>

            {/* Category filters */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 flex-wrap">
              {categories.map(cat => (
                <motion.button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-3 py-1.5 rounded-full text-xs whitespace-nowrap font-medium transition-all duration-200"
                  style={activeCategory === cat ? {
                    background: `linear-gradient(135deg, ${state.accentColor}, ${state.accentColor}cc)`,
                    color: '#000',
                    boxShadow: `0 0 12px ${state.glowColor}`,
                  } : {
                    background: 'rgba(255,255,255,0.05)',
                    color: 'rgba(255,255,255,0.4)',
                    border: '1px solid rgba(255,255,255,0.07)',
                  }}
                >
                  {cat}
                </motion.button>
              ))}
            </div>
          </motion.div>

          {/* Food cards */}
          <div className="flex-1 overflow-y-auto px-6 py-5">
            <AnimatePresence mode="popLayout">
              <motion.div
                key={activeCategory}
                className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4"
              >
                {filteredFoods.map((food, i) => (
                  <motion.div
                    key={food.id}
                    initial={{ opacity: 0, y: 25, scale: 0.96 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.94 }}
                    transition={{ delay: i * 0.07, duration: 0.4, ease: 'easeOut' }}
                  >
                    <FoodCard
                      food={food}
                      language={language}
                      stateColor={state.accentColor}
                      stateGlow={state.glowColor}
                      onClick={() => onFoodClick(food)}
                    />
                  </motion.div>
                ))}
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* State accent border line */}
      <div
        className="absolute left-0 top-0 bottom-0 w-0.5 hidden lg:block"
        style={{ background: `linear-gradient(to bottom, transparent, ${state.accentColor}60, transparent)` }}
      />
    </div>
  );
}

function StateSymbol({ stateId, color }: { stateId: string; color: string }): React.ReactElement {
  const symbols: Record<string, React.ReactElement> = {
    perlis: (
      <svg viewBox="0 0 60 60" width="40" height="40">
        <ellipse cx="30" cy="25" rx="18" ry="16" fill="none" stroke={color} strokeWidth="1.5" />
        <ellipse cx="30" cy="25" rx="10" ry="8" fill={color} opacity="0.25" />
        <circle cx="30" cy="25" r="3.5" fill={color} opacity="0.7" />
        <path d="M 30 40 L 30 48" stroke={color} strokeWidth="1" />
      </svg>
    ),
    kedah: (
      <svg viewBox="0 0 60 60" width="40" height="40">
        <path d="M 12 46 L 30 14 L 48 46 Z" fill="none" stroke={color} strokeWidth="1.5" />
        <line x1="30" y1="14" x2="30" y2="46" stroke={color} strokeWidth="0.8" />
        <line x1="12" y1="34" x2="48" y2="34" stroke={color} strokeWidth="0.8" />
        <circle cx="30" cy="30" r="4" fill={color} opacity="0.4" />
      </svg>
    ),
    penang: (
      <svg viewBox="0 0 60 60" width="40" height="40">
        <path d="M 14 30 Q 30 8 46 30 Q 30 52 14 30 Z" fill="none" stroke={color} strokeWidth="1.5" />
        <circle cx="30" cy="30" r="7" fill={color} opacity="0.25" />
        <path d="M 20 30 Q 30 18 40 30" fill="none" stroke={color} strokeWidth="1" />
        <circle cx="30" cy="30" r="2.5" fill={color} opacity="0.8" />
      </svg>
    ),
    perak: (
      <svg viewBox="0 0 60 60" width="40" height="40">
        <rect x="20" y="14" width="20" height="32" rx="2" fill="none" stroke={color} strokeWidth="1.5" />
        <rect x="24" y="9" width="12" height="10" rx="1" fill={color} opacity="0.35" />
        <circle cx="30" cy="34" r="5" fill="none" stroke={color} strokeWidth="1" />
        <circle cx="30" cy="34" r="2" fill={color} opacity="0.6" />
      </svg>
    ),
    selangor: (
      <svg viewBox="0 0 60 60" width="40" height="40">
        <polygon points="30,8 38,24 56,24 42,34 48,52 30,42 12,52 18,34 4,24 22,24" fill="none" stroke={color} strokeWidth="1.5" />
        <circle cx="30" cy="30" r="5" fill={color} opacity="0.35" />
      </svg>
    ),
    kl: (
      <svg viewBox="0 0 60 60" width="40" height="40">
        <path d="M 26 46 L 26 20 L 30 9 L 34 20 L 34 46" fill="none" stroke={color} strokeWidth="2" />
        <path d="M 20 30 L 40 30" stroke={color} strokeWidth="1.5" />
        <circle cx="30" cy="9" r="3.5" fill={color} opacity="0.7" />
        <rect x="23" y="38" width="14" height="8" rx="1" fill={color} opacity="0.2" />
      </svg>
    ),
    putrajaya: (
      <svg viewBox="0 0 60 60" width="40" height="40">
        <path d="M 14 42 L 14 24 Q 30 8 46 24 L 46 42 Z" fill="none" stroke={color} strokeWidth="1.5" />
        <line x1="22" y1="42" x2="22" y2="28" stroke={color} strokeWidth="1" />
        <line x1="30" y1="42" x2="30" y2="19" stroke={color} strokeWidth="1" />
        <line x1="38" y1="42" x2="38" y2="28" stroke={color} strokeWidth="1" />
        <ellipse cx="30" cy="19" rx="4" ry="5" fill={color} opacity="0.3" />
      </svg>
    ),
    'negeri-sembilan': (
      <svg viewBox="0 0 60 60" width="40" height="40">
        <path d="M 30 8 L 52 20 L 52 40 L 30 52 L 8 40 L 8 20 Z" fill="none" stroke={color} strokeWidth="1.5" />
        <path d="M 30 18 L 44 26 L 44 38 L 30 46 L 16 38 L 16 26 Z" fill={color} opacity="0.15" />
        <circle cx="30" cy="32" r="4" fill={color} opacity="0.5" />
      </svg>
    ),
    melaka: (
      <svg viewBox="0 0 60 60" width="40" height="40">
        <rect x="18" y="20" width="24" height="28" rx="2" fill="none" stroke={color} strokeWidth="1.5" />
        <path d="M 18 28 L 42 28" stroke={color} strokeWidth="0.8" />
        <path d="M 23 20 L 23 13 Q 30 8 37 13 L 37 20" fill="none" stroke={color} strokeWidth="1.5" />
        <circle cx="30" cy="14" r="3" fill={color} opacity="0.5" />
        <rect x="24" y="32" width="5" height="16" fill={color} opacity="0.2" />
        <rect x="31" y="32" width="5" height="16" fill={color} opacity="0.2" />
      </svg>
    ),
    johor: (
      <svg viewBox="0 0 60 60" width="40" height="40">
        <path d="M 8 46 Q 30 8 52 46 Z" fill="none" stroke={color} strokeWidth="1.5" />
        <path d="M 18 36 Q 30 18 42 36" fill="none" stroke={color} strokeWidth="1" />
        <circle cx="30" cy="30" r="5" fill={color} opacity="0.35" />
        <path d="M 30 50 L 30 46" stroke={color} strokeWidth="1.5" />
      </svg>
    ),
    pahang: (
      <svg viewBox="0 0 60 60" width="40" height="40">
        <path d="M 30 8 C 8 18 8 42 30 52 C 52 42 52 18 30 8 Z" fill="none" stroke={color} strokeWidth="1.5" />
        <path d="M 18 30 Q 30 14 42 30" fill="none" stroke={color} strokeWidth="1" />
        <path d="M 16 38 Q 30 52 44 38" fill="none" stroke={color} strokeWidth="0.8" />
      </svg>
    ),
    terengganu: (
      <svg viewBox="0 0 60 60" width="40" height="40">
        <path d="M 14 20 L 30 10 L 46 20 L 46 40 L 30 50 L 14 40 Z" fill="none" stroke={color} strokeWidth="1.5" />
        <path d="M 24 28 Q 30 18 36 28 Q 30 40 24 28 Z" fill={color} opacity="0.35" />
      </svg>
    ),
    kelantan: (
      <svg viewBox="0 0 60 60" width="40" height="40">
        <path d="M 30 6 L 38 16 L 55 16 L 42 26 L 48 44 L 30 34 L 12 44 L 18 26 L 5 16 L 22 16 Z" fill="none" stroke={color} strokeWidth="1.5" />
        <circle cx="30" cy="27" r="4" fill={color} opacity="0.4" />
      </svg>
    ),
    sabah: (
      <svg viewBox="0 0 60 60" width="40" height="40">
        <circle cx="30" cy="30" r="18" fill="none" stroke={color} strokeWidth="1.5" />
        <path d="M 30 12 L 30 48 M 12 30 L 48 30" stroke={color} strokeWidth="1" />
        <path d="M 16.5 16.5 L 43.5 43.5 M 43.5 16.5 L 16.5 43.5" stroke={color} strokeWidth="0.6" />
        <circle cx="30" cy="30" r="5" fill={color} opacity="0.4" />
      </svg>
    ),
    sarawak: (
      <svg viewBox="0 0 60 60" width="40" height="40">
        <path d="M 8 36 Q 20 12 30 20 Q 40 28 52 12" fill="none" stroke={color} strokeWidth="2" />
        <path d="M 12 44 L 48 44" stroke={color} strokeWidth="1.5" />
        <circle cx="30" cy="26" r="6" fill="none" stroke={color} strokeWidth="1" />
        <circle cx="30" cy="26" r="2.5" fill={color} opacity="0.6" />
      </svg>
    ),
    labuan: (
      <svg viewBox="0 0 60 60" width="40" height="40">
        <circle cx="30" cy="30" r="20" fill="none" stroke={color} strokeWidth="1.5" />
        <circle cx="30" cy="30" r="12" fill={color} opacity="0.15" />
        <path d="M 30 10 L 30 50 M 10 30 L 50 30" stroke={color} strokeWidth="0.8" />
        <circle cx="30" cy="30" r="4" fill={color} opacity="0.6" />
      </svg>
    ),
  };

  return symbols[stateId] || (
    <svg viewBox="0 0 60 60" width="40" height="40">
      <circle cx="30" cy="30" r="18" fill="none" stroke={color} strokeWidth="1.5" />
      <circle cx="30" cy="30" r="8" fill={color} opacity="0.35" />
    </svg>
  );
}
