import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface Props {
  onEnter: () => void;
  language: string;
}

// Floating food emoji items for atmosphere
const floatingItems = ['🌶️', '🍜', '🥥', '🍛', '🫙', '🌿', '🐟', '🍚', '☕', '🦐', '🌺', '🍃'];

const culturalFacts = [
  { en: '16 States', bm: '16 Negeri', zh: '16个州' },
  { en: '3 Major Cultures', bm: '3 Budaya Utama', zh: '3大文化' },
  { en: '80+ Iconic Dishes', bm: '80+ Hidangan Ikonik', zh: '80+标志性菜肴' },
  { en: '1 Beautiful Country', bm: '1 Negara Cantik', zh: '1个美丽国家' },
];

export default function WelcomeScreen({ onEnter }: Props) {
  const [loaded, setLoaded] = useState(false);
  const [particles, setParticles] = useState<
    { x: number; y: number; size: number; delay: number; speed: number; color: string }[]
  >([]);


  useEffect(() => {
    const timer = setTimeout(() => setLoaded(true), 100);
    const colors = ['#f59e0b', '#ef4444', '#10b981', '#f97316', '#fbbf24'];
    const p = Array.from({ length: 25 }, (_, i) => ({
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 3 + 1,
      delay: Math.random() * 5,
      speed: Math.random() * 5 + 4,
      color: colors[i % colors.length],
    }));
    setParticles(p);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="relative w-full h-screen overflow-hidden select-none">
      {/* Layered cinematic background */}
      <div className="absolute inset-0">
        {/* Base dark layer */}
        <div className="absolute inset-0 bg-[#0a0508]" />

        {/* Hero background image */}
        <motion.div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: 'url(/images/hero-bg.jpg)' }}
          initial={{ scale: 1.08 }}
          animate={{ scale: 1 }}
          transition={{ duration: 8, ease: 'easeOut' }}

        />

        {/* Multi-layer cinematic overlays */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/75 via-black/35 to-black/85" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/40 via-transparent to-black/40" />
        {/* Warm color grade */}
        <div className="absolute inset-0 bg-gradient-to-br from-amber-900/25 via-transparent to-red-900/20" />
        {/* Vignette */}
        <div className="absolute inset-0"
          style={{ boxShadow: 'inset 0 0 200px rgba(0,0,0,0.7)' }} />
      </div>

      {/* Floating ambient particles */}
      {particles.map((p, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full pointer-events-none"
          style={{
            left: `${p.x}%`,
            top: `${p.y}%`,
            width: p.size,
            height: p.size,
            background: p.color,
          }}
          animate={{
            y: [-20, 20, -20],
            x: [-5, 5, -5],
            opacity: [0.1, 0.5, 0.1],
          }}
          transition={{
            duration: p.speed,
            delay: p.delay,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        />
      ))}

      {/* Batik pattern overlay - very subtle */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='40' fill='none' stroke='%23f59e0b' stroke-width='0.3' opacity='0.15'/%3E%3Ccircle cx='50' cy='50' r='25' fill='none' stroke='%23f59e0b' stroke-width='0.2' opacity='0.1'/%3E%3Ccircle cx='50' cy='50' r='10' fill='none' stroke='%23f59e0b' stroke-width='0.15' opacity='0.08'/%3E%3Cline x1='10' y1='50' x2='90' y2='50' stroke='%23f59e0b' stroke-width='0.2' opacity='0.06'/%3E%3Cline x1='50' y1='10' x2='50' y2='90' stroke='%23f59e0b' stroke-width='0.2' opacity='0.06'/%3E%3C/svg%3E")`,
          backgroundSize: '80px 80px',
          opacity: 0.4,
        }}
      />

      {/* Top decorative header */}
      <div className="absolute top-0 left-0 right-0 z-20">
        {/* Malaysian flag stripe pattern */}
        <div className="flex h-1">
          {Array.from({ length: 28 }).map((_, i) => (
            <div key={i} className="flex-1" style={{
              background: i % 2 === 0 ? 'rgba(220,38,38,0.8)' : 'rgba(255,255,255,0.8)'
            }} />
          ))}
        </div>
        {/* Amber glow line */}
        <div className="h-px bg-gradient-to-r from-transparent via-amber-400/60 to-transparent" />

        {/* Top nav */}
        <div className="flex items-center justify-between px-8 py-4">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: loaded ? 1 : 0, x: loaded ? 0 : -20 }}
            transition={{ delay: 1, duration: 0.6 }}
            className="flex items-center gap-2"
          >
            <span className="text-amber-400/60 text-xs tracking-widest uppercase font-light">
              Malaysia Tourism
            </span>
          </motion.div>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: loaded ? 1 : 0 }}
            transition={{ delay: 1.2 }}
            className="flex items-center gap-2"
          >
            <span className="text-white/20 text-xs tracking-widest">TRULY ASIA • 真正的亚洲</span>
          </motion.div>
        </div>
      </div>

      {/* Wau bulan decorative SVG - top right */}
      <motion.div
        className="absolute top-16 right-10 opacity-15 pointer-events-none"
        animate={{ rotate: [0, 3, -3, 0], y: [0, -5, 0] }}
        transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
      >
        <svg width="140" height="155" viewBox="0 0 140 155">
          <ellipse cx="70" cy="75" rx="60" ry="70" fill="none" stroke="#f59e0b" strokeWidth="1" />
          <ellipse cx="70" cy="75" rx="42" ry="50" fill="none" stroke="#f59e0b" strokeWidth="0.6" />
          <ellipse cx="70" cy="75" rx="24" ry="30" fill="none" stroke="#f59e0b" strokeWidth="0.4" />
          <line x1="70" y1="5" x2="70" y2="145" stroke="#f59e0b" strokeWidth="0.6" />
          <line x1="10" y1="75" x2="130" y2="75" stroke="#f59e0b" strokeWidth="0.6" />
          <path d="M 18 38 Q 70 8 122 38" fill="none" stroke="#f59e0b" strokeWidth="0.8" />
          <path d="M 12 75 Q 70 108 128 75" fill="none" stroke="#f59e0b" strokeWidth="0.8" />
          <path d="M 25 108 Q 70 132 115 108" fill="none" stroke="#f59e0b" strokeWidth="0.6" />
          <circle cx="70" cy="75" r="6" fill="#f59e0b" opacity="0.4" />
          {/* Tail */}
          <path d="M 70 145 L 65 175 L 70 155 L 75 175 Z" fill="#f59e0b" opacity="0.3" />
        </svg>
      </motion.div>

      {/* Rangoli/batik ornament - bottom left */}
      <motion.div
        className="absolute bottom-20 left-10 opacity-10 pointer-events-none"
        animate={{ rotate: [0, 360] }}
        transition={{ duration: 40, repeat: Infinity, ease: 'linear' }}
      >
        <svg width="120" height="120" viewBox="0 0 120 120">
          {[0, 45, 90, 135].map(angle => (
            <g key={angle} transform={`rotate(${angle} 60 60)`}>
              <ellipse cx="60" cy="30" rx="10" ry="25" fill="none" stroke="#ec4899" strokeWidth="0.8" />
              <ellipse cx="60" cy="90" rx="10" ry="25" fill="none" stroke="#ec4899" strokeWidth="0.8" />
            </g>
          ))}
          <circle cx="60" cy="60" r="15" fill="none" stroke="#ec4899" strokeWidth="0.8" />
          <circle cx="60" cy="60" r="5" fill="#ec4899" opacity="0.4" />
        </svg>
      </motion.div>

      {/* Main content */}
      <AnimatePresence>
        <div className="relative z-10 flex flex-col items-center justify-center h-full text-center px-6">
          {/* Pre-title badge */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: loaded ? 1 : 0, y: loaded ? 0 : 30 }}
            transition={{ delay: 0.6, duration: 0.8, ease: 'easeOut' }}
            className="mb-6"
          >
            <div
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full border"
              style={{
                background: 'rgba(245,158,11,0.08)',
                borderColor: 'rgba(245,158,11,0.25)',
                backdropFilter: 'blur(10px)',
              }}
            >
              <div className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
              <span className="text-amber-400/80 text-xs tracking-[0.35em] uppercase font-light">
                An Immersive Cultural Journey
              </span>
              <div className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
            </div>
          </motion.div>

          {/* Main title */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: loaded ? 1 : 0, y: loaded ? 0 : 40 }}
            transition={{ delay: 0.9, duration: 1.2, ease: 'easeOut' }}
          >
            <p className="text-white/40 text-lg tracking-[0.3em] uppercase font-light mb-2">
              Welcome to
            </p>
            <h1
              className="text-7xl md:text-9xl font-bold text-white leading-none mb-2"
              style={{
                fontFamily: "'Playfair Display', serif",
                textShadow: '0 0 80px rgba(245,158,11,0.25), 0 4px 8px rgba(0,0,0,0.9)',
              }}
            >
              <span className="text-transparent bg-clip-text bg-gradient-to-b from-amber-200 via-amber-400 to-amber-600">
                Malaysia
              </span>
            </h1>
          </motion.div>

          {/* Decorative divider with kris motif */}
          <motion.div
            initial={{ scaleX: 0, opacity: 0 }}
            animate={{ scaleX: loaded ? 1 : 0, opacity: loaded ? 1 : 0 }}
            transition={{ delay: 1.6, duration: 0.8 }}
            className="flex items-center gap-3 my-6"
          >
            <div className="h-px w-20 bg-gradient-to-r from-transparent to-amber-400/60" />
            <div className="flex items-center gap-1">
              <div className="w-1.5 h-1.5 rotate-45 bg-amber-400/60" />
              <div className="w-2.5 h-2.5 rotate-45 bg-amber-400/80" />
              <div className="w-1.5 h-1.5 rotate-45 bg-amber-400/60" />
            </div>
            <div className="h-px w-20 bg-gradient-to-l from-transparent to-amber-400/60" />
          </motion.div>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: loaded ? 1 : 0, y: loaded ? 0 : 20 }}
            transition={{ delay: 1.9, duration: 0.9 }}
            className="text-xl md:text-2xl font-light tracking-wide mb-10 max-w-xl"
            style={{
              color: 'rgba(255,255,255,0.65)',
              textShadow: '0 2px 8px rgba(0,0,0,0.6)',
            }}
          >
            Discover the Flavours of Every State
          </motion.p>

          {/* Cultural stats */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: loaded ? 1 : 0, y: loaded ? 0 : 15 }}
            transition={{ delay: 2.2, duration: 0.8 }}
            className="flex flex-wrap items-center justify-center gap-6 mb-10"
          >
            {culturalFacts.map((fact, i) => (
              <div key={i} className="flex items-center gap-2">
                {i > 0 && <div className="w-px h-5 bg-white/15" />}
                <span className="text-white/40 text-sm font-light">{fact.en}</span>
              </div>
            ))}
          </motion.div>

          {/* CTA Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: loaded ? 1 : 0, y: loaded ? 0 : 20 }}
            transition={{ delay: 2.5, duration: 0.8 }}
          >
            <motion.button
              onClick={onEnter}
              whileHover={{
                scale: 1.05,
                boxShadow: '0 0 50px rgba(245,158,11,0.5), 0 0 100px rgba(245,158,11,0.2)',
              }}
              whileTap={{ scale: 0.97 }}
              className="relative group px-12 py-4 rounded-full overflow-hidden cursor-pointer"
              style={{
                background: 'linear-gradient(135deg, #f59e0b, #d97706, #b45309)',
                boxShadow: '0 0 30px rgba(245,158,11,0.35), 0 4px 20px rgba(0,0,0,0.4)',
              }}
            >
              {/* Shine effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
              {/* Inner glow */}
              <div className="absolute inset-0 rounded-full"
                style={{ boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.3), inset 0 -1px 0 rgba(0,0,0,0.2)' }} />
              <span className="relative text-black font-bold text-base tracking-widest uppercase">
                Begin the Journey
              </span>
              <span className="relative ml-3 text-black/70">→</span>
            </motion.button>
          </motion.div>

          {/* Multilingual hint */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: loaded ? 1 : 0 }}
            transition={{ delay: 3, duration: 1 }}
            className="mt-6 text-white/20 text-xs tracking-widest"
          >
            Available in English · Bahasa Melayu · 中文
          </motion.p>
        </div>
      </AnimatePresence>

      {/* Floating food icons on sides */}
      {floatingItems.map((item, i) => {
        const isLeft = i % 2 === 0;
        const yPos = 10 + (i / floatingItems.length) * 80;
        return (
          <motion.div
            key={i}
            className="absolute text-xl md:text-2xl pointer-events-none"
            style={{
              left: isLeft ? `${3 + Math.random() * 5}%` : undefined,
              right: !isLeft ? `${3 + Math.random() * 5}%` : undefined,
              top: `${yPos}%`,
            }}
            animate={{
              y: [-8, 8, -8],
              opacity: [0.08, 0.25, 0.08],
              rotate: [-5, 5, -5],
            }}
            transition={{
              duration: 4 + i * 0.3,
              delay: i * 0.4,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
          >
            {item}
          </motion.div>
        );
      })}

      {/* Bottom gradient */}
      <div className="absolute bottom-0 left-0 right-0 h-40 bg-gradient-to-t from-black/80 to-transparent pointer-events-none" />

      {/* Bottom tagline */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: loaded ? 1 : 0 }}
        transition={{ delay: 3.5, duration: 1 }}
        className="absolute bottom-6 left-0 right-0 flex items-center justify-center gap-3"
      >
        <div className="h-px w-16 bg-white/10" />
        <span className="text-white/15 text-xs tracking-widest">
          MALAYSIA TRULY ASIA
        </span>
        <div className="h-px w-16 bg-white/10" />
      </motion.div>
    </div>
  );
}
