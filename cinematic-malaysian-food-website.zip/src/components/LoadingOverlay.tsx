import { motion } from 'framer-motion';

interface Props {
  color?: string;
}

export default function LoadingOverlay({ color = '#f59e0b' }: Props) {
  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#05050d]"
    >
      <div className="flex flex-col items-center gap-4">
        {/* Animated Malaysia-inspired loader */}
        <div className="relative w-16 h-16">
          <motion.div
            className="absolute inset-0 rounded-full border-2"
            style={{ borderColor: `${color}40` }}
          />
          <motion.div
            className="absolute inset-0 rounded-full border-t-2"
            style={{ borderColor: color }}
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
          />
          <motion.div
            className="absolute inset-2 rounded-full border-t-2 border-r-2"
            style={{ borderColor: `${color}60` }}
            animate={{ rotate: -360 }}
            transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}
          />
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-xl">🇲🇾</span>
          </div>
        </div>
        <motion.p
          animate={{ opacity: [0.4, 1, 0.4] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          className="text-white/40 text-xs tracking-widest uppercase"
        >
          Loading...
        </motion.p>
      </div>
    </motion.div>
  );
}
