import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Flame, Leaf, MapPin, BookOpen, ChefHat, History, Star } from 'lucide-react';
import { Food, State, Language, translations } from '../data/malaysiaData';

interface Props {
  food: Food;
  state: State;
  language: Language;
  onBack: () => void;
}

function SpiceBar({ level }: { level: number }) {
  const config = [
    { label: '', color: '' },
    { label: 'Mild', color: '#22c55e' },
    { label: 'Light', color: '#84cc16' },
    { label: 'Medium', color: '#f59e0b' },
    { label: 'Hot', color: '#f97316' },
    { label: 'Extreme 🔥', color: '#ef4444' },
  ];
  const current = config[level] || config[0];

  if (level === 0) {
    return (
      <div className="flex items-center gap-2">
        <span className="text-sm text-green-400 font-medium">No Spice</span>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-3">
      <div className="flex gap-1 items-end">
        {[1, 2, 3, 4, 5].map(i => (
          <motion.div
            key={i}
            initial={{ scaleY: 0 }}
            animate={{ scaleY: 1 }}
            transition={{ delay: 0.1 + i * 0.08, duration: 0.35 }}
            className="w-3 rounded-t-sm origin-bottom"
            style={{
              height: `${10 + i * 5}px`,
              background: i <= level ? current.color : 'rgba(255,255,255,0.08)',
              boxShadow: i <= level ? `0 0 6px ${current.color}60` : 'none',
            }}
          />
        ))}
      </div>
      <span className="text-sm font-semibold" style={{ color: current.color }}>
        {current.label}
      </span>
    </div>
  );
}

export default function FoodDetail({ food, state, language, onBack }: Props) {
  const [imageError, setImageError] = useState(false);
  const [activeTab, setActiveTab] = useState<'story' | 'ingredients' | 'places'>('story');
  const t = translations[language];

  const getFoodName = () => {
    if (language === 'bm') return food.nameBM;
    if (language === 'zh') return food.nameZH;
    return food.name;
  };

  const getDescription = () => {
    if (language === 'bm') return food.descriptionBM;
    if (language === 'zh') return food.descriptionZH;
    return food.description;
  };

  const getStateName = () => {
    if (language === 'bm') return state.nameBM;
    if (language === 'zh') return state.nameZH;
    return state.name;
  };

  const tabs = [
    { id: 'story' as const, label: 'Story & Culture', icon: BookOpen },
    { id: 'ingredients' as const, label: t.ingredients, icon: ChefHat },
    { id: 'places' as const, label: 'Where to Eat', icon: MapPin },
  ];

  return (
    <div className="relative w-full h-screen overflow-hidden bg-[#05050d]">
      {/* Cinematic background with state-based ambient light */}
      <div className="absolute inset-0">
        <div
          className="absolute inset-0"
          style={{
            background: `radial-gradient(ellipse at 35% 15%, ${state.accentColor}20, transparent 50%)`,
          }}
        />
        <div
          className="absolute bottom-0 right-0 w-3/4 h-3/4"
          style={{
            background: `radial-gradient(ellipse at 70% 80%, ${state.accentColor}10, transparent 55%)`,
          }}
        />
      </div>

      {/* Content layout */}
      <div className="relative z-10 w-full h-full flex flex-col lg:flex-row">
        {/* LEFT: Food Image Panel */}
        <div className="relative w-full lg:w-[45%] xl:w-[42%] h-56 sm:h-72 lg:h-full flex-shrink-0 overflow-hidden">
          {/* Food image with parallax-like entrance */}
          <motion.div
            className="absolute inset-0"
            initial={{ scale: 1.12 }}
            animate={{ scale: 1 }}
            transition={{ duration: 1.2, ease: 'easeOut' }}
          >
            <img
              src={imageError ? '/images/nasi-lemak.jpg' : food.image}
              alt={getFoodName()}
              onError={() => setImageError(true)}
              className="w-full h-full object-cover"
            />
          </motion.div>

          {/* Multiple overlay layers for cinematic depth */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-black/20 lg:bg-none" />
          <div className="absolute inset-0 hidden lg:block"
            style={{ background: 'linear-gradient(to right, transparent 55%, rgba(5,5,13,1) 100%)' }}
          />
          <div className="absolute inset-0 hidden lg:block"
            style={{ background: 'linear-gradient(to bottom, rgba(0,0,0,0.4) 0%, transparent 30%, transparent 70%, rgba(0,0,0,0.5) 100%)' }}
          />

          {/* Warm cinematic color grade */}
          <div className="absolute inset-0 mix-blend-overlay opacity-30"
            style={{ background: `linear-gradient(135deg, ${state.accentColor}40, transparent)` }}
          />

          {/* Vignette */}
          <div className="absolute inset-0"
            style={{ boxShadow: 'inset 0 0 80px rgba(0,0,0,0.4)' }}
          />

          {/* Back button */}
          <motion.button
            initial={{ opacity: 0, x: -15 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            onClick={onBack}
            whileHover={{ x: -4, scale: 1.04 }}
            whileTap={{ scale: 0.95 }}
            className="absolute top-5 left-5 z-20 flex items-center gap-2 px-3 py-2 rounded-xl backdrop-blur-xl transition-all"
            style={{
              background: 'rgba(5,5,13,0.6)',
              border: '1px solid rgba(255,255,255,0.1)',
            }}
          >
            <ArrowLeft size={14} className="text-white/70" />
            <span className="text-white/70 text-xs font-medium">{getStateName()}</span>
          </motion.button>

          {/* Food category badge */}
          <div className="absolute top-5 right-5 z-20">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3 }}
              className="px-3 py-1.5 rounded-full backdrop-blur-xl text-xs font-medium"
              style={{
                background: `${state.accentColor}25`,
                border: `1px solid ${state.accentColor}50`,
                color: state.accentColor,
              }}
            >
              {food.category}
            </motion.div>
          </div>

          {/* Bottom attribution on image (mobile visible) */}
          <div className="absolute bottom-0 left-0 right-0 p-5 lg:hidden">
            <h2 className="text-white text-2xl font-bold"
              style={{ fontFamily: "'Playfair Display', serif" }}>
              {getFoodName()}
            </h2>
          </div>
        </div>

        {/* RIGHT: Food Details */}
        <div className="flex-1 overflow-y-auto flex flex-col">
          <div className="flex-1 px-6 lg:px-10 xl:px-12 py-6 lg:py-10 flex flex-col">
            {/* Food header (desktop) */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.7 }}
              className="mb-6 hidden lg:block"
            >
              {/* Badges */}
              <div className="flex flex-wrap gap-2 mb-4">
                <span
                  className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium"
                  style={{
                    background: `${state.accentColor}18`,
                    border: `1px solid ${state.accentColor}35`,
                    color: state.accentColor,
                  }}
                >
                  <Star size={9} />
                  {food.origin}
                </span>
                <span
                  className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium ${
                    food.isHalal
                      ? 'text-green-400'
                      : 'text-red-400'
                  }`}
                  style={food.isHalal ? {
                    background: 'rgba(34,197,94,0.1)',
                    border: '1px solid rgba(34,197,94,0.25)',
                  } : {
                    background: 'rgba(239,68,68,0.1)',
                    border: '1px solid rgba(239,68,68,0.25)',
                  }}
                >
                  <Leaf size={9} />
                  {food.isHalal ? t.halal : t.nonHalal}
                </span>
              </div>

              {/* Title */}
              <h1
                className="text-4xl xl:text-5xl font-bold text-white leading-tight mb-3"
                style={{
                  fontFamily: "'Playfair Display', serif",
                  textShadow: `0 0 30px ${state.glowColor}`,
                }}
              >
                {getFoodName()}
              </h1>

              {/* Accent line */}
              <div className="h-0.5 w-20 mb-4"
                style={{ background: `linear-gradient(to right, ${state.accentColor}, transparent)` }} />

              {/* Description */}
              <p className="text-white/55 text-base leading-relaxed max-w-lg">
                {getDescription()}
              </p>
            </motion.div>

            {/* Spice level section */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.35 }}
              className="flex flex-col sm:flex-row sm:items-center gap-4 sm:gap-8 mb-6 p-4 rounded-2xl"
              style={{
                background: 'rgba(255,255,255,0.025)',
                border: '1px solid rgba(255,255,255,0.055)',
              }}
            >
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Flame size={13} className="text-orange-400" />
                  <p className="text-white/40 text-xs uppercase tracking-wider">{t.spiceLevel}</p>
                </div>
                <SpiceBar level={food.spiceLevel} />
              </div>

              <div className="w-px h-10 bg-white/08 hidden sm:block" />

              <div>
                <p className="text-white/30 text-xs uppercase tracking-wider mb-1.5">Status</p>
                <div className={`flex items-center gap-2 text-sm font-semibold ${food.isHalal ? 'text-green-400' : 'text-red-400'}`}>
                  <Leaf size={14} />
                  <span>{food.isHalal ? t.halal : t.nonHalal}</span>
                </div>
              </div>
            </motion.div>

            {/* Tabs navigation */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="flex gap-1 mb-4 p-1 rounded-xl"
              style={{ background: 'rgba(255,255,255,0.025)' }}
            >
              {tabs.map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className="flex items-center justify-center gap-1.5 flex-1 px-3 py-2.5 rounded-lg text-xs font-medium transition-all duration-250"
                  style={activeTab === tab.id ? {
                    background: `linear-gradient(135deg, ${state.accentColor}, ${state.accentColor}cc)`,
                    color: '#000',
                    boxShadow: `0 2px 12px ${state.glowColor}`,
                  } : {
                    color: 'rgba(255,255,255,0.35)',
                  }}
                >
                  <tab.icon size={11} />
                  <span className="hidden sm:inline">{tab.label}</span>
                </button>
              ))}
            </motion.div>

            {/* Tab content */}
            <div className="flex-1 min-h-0">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeTab}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.25 }}
                  className="h-full rounded-2xl p-5 overflow-y-auto"
                  style={{
                    background: 'rgba(255,255,255,0.02)',
                    border: '1px solid rgba(255,255,255,0.045)',
                  }}
                >
                  {activeTab === 'story' && (
                    <div className="space-y-5">
                      {/* History */}
                      <div>
                        <div className="flex items-center gap-2 mb-2.5">
                          <div className="w-5 h-5 rounded-md flex items-center justify-center"
                            style={{ background: `${state.accentColor}25` }}>
                            <History size={11} style={{ color: state.accentColor }} />
                          </div>
                          <h3 className="text-white/70 text-xs font-semibold uppercase tracking-wider">{t.history}</h3>
                        </div>
                        <p className="text-white/45 text-sm leading-relaxed pl-7">{food.history}</p>
                      </div>

                      {/* Divider */}
                      <div className="h-px mx-7"
                        style={{ background: 'rgba(255,255,255,0.05)' }} />

                      {/* Cultural background */}
                      <div>
                        <div className="flex items-center gap-2 mb-2.5">
                          <div className="w-5 h-5 rounded-md flex items-center justify-center"
                            style={{ background: `${state.accentColor}25` }}>
                            <BookOpen size={11} style={{ color: state.accentColor }} />
                          </div>
                          <h3 className="text-white/70 text-xs font-semibold uppercase tracking-wider">{t.culturalBackground}</h3>
                        </div>
                        <p className="text-white/45 text-sm leading-relaxed pl-7">{food.culturalBackground}</p>
                      </div>

                      {/* Cultural quote decoration */}
                      <div className="mt-4 pl-7">
                        <div className="flex items-start gap-3">
                          <div className="text-3xl leading-none" style={{ color: state.accentColor, opacity: 0.3 }}>"</div>
                          <p className="text-white/25 text-xs italic leading-relaxed">
                            Malaysia's culinary landscape is as diverse as its people — every dish tells a story of migration, trade, and love.
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  {activeTab === 'ingredients' && (
                    <div>
                      <div className="flex items-center gap-2 mb-4">
                        <div className="w-5 h-5 rounded-md flex items-center justify-center"
                          style={{ background: `${state.accentColor}25` }}>
                          <ChefHat size={11} style={{ color: state.accentColor }} />
                        </div>
                        <h3 className="text-white/70 text-xs font-semibold uppercase tracking-wider">{t.ingredients}</h3>
                        <span className="text-white/20 text-xs ml-1">({food.ingredients.length} items)</span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {food.ingredients.map((ingredient, i) => (
                          <motion.span
                            key={ingredient}
                            initial={{ opacity: 0, scale: 0.85 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ delay: i * 0.04, duration: 0.3 }}
                            className="px-3.5 py-1.5 rounded-full text-sm"
                            style={{
                              background: `${state.accentColor}12`,
                              border: `1px solid ${state.accentColor}28`,
                              color: 'rgba(255,255,255,0.65)',
                            }}
                          >
                            {ingredient}
                          </motion.span>
                        ))}
                      </div>

                      {/* Cooking note */}
                      <div className="mt-5 p-3 rounded-xl"
                        style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.04)' }}>
                        <p className="text-white/25 text-xs italic">
                          💡 Ingredients may vary by region and family recipe tradition.
                        </p>
                      </div>
                    </div>
                  )}

                  {activeTab === 'places' && (
                    <div>
                      <div className="flex items-center gap-2 mb-4">
                        <div className="w-5 h-5 rounded-md flex items-center justify-center"
                          style={{ background: `${state.accentColor}25` }}>
                          <MapPin size={11} style={{ color: state.accentColor }} />
                        </div>
                        <h3 className="text-white/70 text-xs font-semibold uppercase tracking-wider">
                          {t.recommendedPlaces}
                        </h3>
                      </div>
                      <div className="space-y-2.5">
                        {food.recommendedPlaces.map((place, i) => (
                          <motion.div
                            key={place}
                            initial={{ opacity: 0, x: -12 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: i * 0.08, duration: 0.35 }}
                            className="flex items-start gap-3 p-3.5 rounded-xl group hover:scale-[1.01] transition-transform"
                            style={{
                              background: 'rgba(255,255,255,0.025)',
                              border: '1px solid rgba(255,255,255,0.05)',
                            }}
                          >
                            <div
                              className="w-6 h-6 rounded-lg flex items-center justify-center flex-shrink-0 text-xs font-bold"
                              style={{
                                background: `${state.accentColor}25`,
                                color: state.accentColor,
                                boxShadow: `0 0 8px ${state.glowColor}`,
                              }}
                            >
                              {i + 1}
                            </div>
                            <div>
                              <p className="text-white/60 text-sm leading-relaxed">{place}</p>
                            </div>
                          </motion.div>
                        ))}
                      </div>

                      <div className="mt-4 p-3 rounded-xl"
                        style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.04)' }}>
                        <p className="text-white/25 text-xs italic">
                          🗺️ Best experienced fresh at local markets and traditional restaurants.
                        </p>
                      </div>
                    </div>
                  )}
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>

      {/* Accent side line */}
      <div
        className="absolute left-0 top-0 bottom-0 w-0.5 hidden lg:block z-10"
        style={{ background: `linear-gradient(to bottom, transparent, ${state.accentColor}50, transparent)` }}
      />

      {/* Top fade */}
      <div className="absolute top-0 left-0 right-0 h-1 z-10"
        style={{ background: `linear-gradient(to right, transparent, ${state.accentColor}40, transparent)` }} />
    </div>
  );
}
