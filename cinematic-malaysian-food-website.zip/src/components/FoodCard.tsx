import { useState } from 'react';
import { motion } from 'framer-motion';
import { Flame, Leaf, ChevronRight } from 'lucide-react';
import { Food, Language, translations } from '../data/malaysiaData';

interface Props {
  food: Food;
  language: Language;
  stateColor: string;
  stateGlow: string;
  onClick: () => void;
}

function SpiceIndicator({ level }: { level: number }) {
  if (level === 0) {
    return <span className="text-green-400 text-xs">No Spice</span>;
  }
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map(i => (
        <Flame
          key={i}
          size={9}
          className={i <= level ? 'text-red-400' : 'text-white/12'}
          fill={i <= level ? '#f87171' : 'none'}
        />
      ))}
    </div>
  );
}

// Map of food images with fallback priority
const imageFallbacks: Record<string, string[]> = {
  '/images/penang-char-kway-teow.jpg': ['/images/assam-laksa.jpg', '/images/nasi-lemak.jpg'],
  '/images/assam-laksa.jpg': ['/images/sarawak-laksa.jpg', '/images/nasi-lemak.jpg'],
  '/images/nasi-lemak.jpg': ['/images/rendang.jpg', '/images/satay.jpg'],
  '/images/rendang.jpg': ['/images/satay.jpg', '/images/nasi-lemak.jpg'],
  '/images/satay.jpg': ['/images/cendol.jpg', '/images/nasi-lemak.jpg'],
  '/images/cendol.jpg': ['/images/nasi-kerabu.jpg', '/images/nasi-lemak.jpg'],
  '/images/nasi-kerabu.jpg': ['/images/assam-laksa.jpg', '/images/nasi-lemak.jpg'],
  '/images/sarawak-laksa.jpg': ['/images/assam-laksa.jpg', '/images/nasi-lemak.jpg'],
};

export default function FoodCard({ food, language, stateColor, stateGlow, onClick }: Props) {
  const [imageIndex, setImageIndex] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  const t = translations[language];

  const getImageSrc = () => {
    if (imageIndex === 0) return food.image;
    const fallbacks = imageFallbacks[food.image] || [];
    return fallbacks[imageIndex - 1] || '/images/nasi-lemak.jpg';
  };

  const handleImageError = () => {
    const fallbacks = imageFallbacks[food.image] || [];
    if (imageIndex < fallbacks.length) {
      setImageIndex(prev => prev + 1);
    }
  };

  const getFoodName = () => {
    if (language === 'bm') return food.nameBM;
    if (language === 'zh') return food.nameZH;
    return food.name;
  };

  const getDescription = () => {
    if (language === 'bm') return food.descriptionBM;
    if (language === 'zh') return food.descriptionZH;
    return food.description;
  };

  return (
    <motion.article
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={onClick}
      whileHover={{ y: -5, scale: 1.01 }}
      whileTap={{ scale: 0.98 }}
      className="relative rounded-2xl overflow-hidden cursor-pointer group"
      style={{
        background: isHovered
          ? `linear-gradient(135deg, ${stateColor}10, rgba(255,255,255,0.03))`
          : 'rgba(255,255,255,0.025)',
        border: `1px solid ${isHovered ? stateColor + '45' : 'rgba(255,255,255,0.06)'}`,
        boxShadow: isHovered
          ? `0 12px 40px rgba(0,0,0,0.5), 0 0 25px ${stateGlow}`
          : '0 4px 16px rgba(0,0,0,0.2)',
        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
      }}
    >
      {/* Food image container */}
      <div className="relative h-44 overflow-hidden">
        <motion.img
          src={getImageSrc()}
          alt={getFoodName()}
          onError={handleImageError}
          className="w-full h-full object-cover"
          animate={{ scale: isHovered ? 1.08 : 1 }}
          transition={{ duration: 0.5, ease: 'easeOut' }}
        />

        {/* Gradient overlays */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/15 to-transparent" />
        {isHovered && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute inset-0"
            style={{ background: `linear-gradient(135deg, ${stateColor}20, transparent)` }}
          />
        )}

        {/* Top badges */}
        <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5">
          <span
            className="px-2 py-0.5 rounded-full text-xs font-medium backdrop-blur-md"
            style={{
              background: `${stateColor}25`,
              border: `1px solid ${stateColor}45`,
              color: stateColor,
            }}
          >
            {food.category}
          </span>
        </div>

        <div className="absolute top-2.5 right-2.5">
          <span
            className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-xs backdrop-blur-md ${
              food.isHalal ? 'text-green-300' : 'text-red-300'
            }`}
            style={{
              background: food.isHalal ? 'rgba(34,197,94,0.15)' : 'rgba(239,68,68,0.15)',
              border: food.isHalal ? '1px solid rgba(34,197,94,0.35)' : '1px solid rgba(239,68,68,0.35)',
            }}
          >
            <Leaf size={7} />
            {food.isHalal ? t.halal : t.nonHalal}
          </span>
        </div>

        {/* Bottom spice level */}
        <div className="absolute bottom-2.5 left-2.5">
          <SpiceIndicator level={food.spiceLevel} />
        </div>

        {/* Bottom right - origin tag */}
        <div className="absolute bottom-2.5 right-2.5">
          <span className="text-white/30 text-xs">{food.origin}</span>
        </div>
      </div>

      {/* Card content */}
      <div className="p-4">
        {/* Title */}
        <h3
          className="font-bold text-sm leading-tight mb-1.5 transition-colors duration-200"
          style={{ color: isHovered ? '#fff' : 'rgba(255,255,255,0.88)' }}
        >
          {getFoodName()}
        </h3>

        {/* Description */}
        <p className="text-white/35 text-xs leading-relaxed line-clamp-2 mb-3">
          {getDescription()}
        </p>

        {/* Bottom row */}
        <div className="flex items-center justify-between">
          {/* Origin dot */}
          <div className="flex items-center gap-1.5">
            <motion.div
              className="w-1.5 h-1.5 rounded-full"
              style={{ background: stateColor }}
              animate={isHovered ? { scale: [1, 1.5, 1], opacity: [0.6, 1, 0.6] } : {}}
              transition={{ duration: 1, repeat: Infinity }}
            />
            <span className="text-white/25 text-xs truncate max-w-[90px]">{food.origin}</span>
          </div>

          {/* Explore link */}
          <motion.div
            className="flex items-center gap-0.5 text-xs font-medium"
            style={{ color: isHovered ? stateColor : 'rgba(255,255,255,0.2)' }}
            animate={{ x: isHovered ? 2 : 0 }}
            transition={{ duration: 0.2 }}
          >
            <span>{t.learnMore}</span>
            <ChevronRight size={11} />
          </motion.div>
        </div>
      </div>

      {/* Bottom accent line */}
      <motion.div
        className="absolute bottom-0 left-4 right-4 h-px"
        animate={{
          background: isHovered
            ? `linear-gradient(to right, transparent, ${stateColor}70, transparent)`
            : 'transparent',
        }}
        transition={{ duration: 0.3 }}
      />

      {/* Corner indicator */}
      {isHovered && (
        <motion.div
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 1, scale: 1 }}
          className="absolute top-2.5 left-2.5 w-1 h-1 rounded-full"
          style={{ background: stateColor, boxShadow: `0 0 6px ${stateColor}` }}
        />
      )}
    </motion.article>
  );
}
