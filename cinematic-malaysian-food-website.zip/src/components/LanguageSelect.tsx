import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Language } from '../data/malaysiaData';
import { ChevronRight } from 'lucide-react';

interface Props {
  onSelect: (lang: Language) => void;
}

const languages = [
  {
    code: 'en' as Language,
    name: 'English',
    native: 'English',
    flag: '🇬🇧',
    label: 'Continue',
    desc: 'International Language',
    gradient: 'linear-gradient(135deg, rgba(59,130,246,0.2), rgba(37,99,235,0.1))',
    border: 'rgba(59,130,246,0.3)',
    glow: 'rgba(59,130,246,0.4)',
    accent: '#3b82f6',
    hoverBg: 'rgba(59,130,246,0.15)',
    cultural: 'Explore in English',
  },
  {
    code: 'bm' as Language,
    name: 'Bahasa Melayu',
    native: 'Bahasa Melayu',
    flag: '🇲🇾',
    label: 'Teruskan',
    desc: 'Bahasa Rasmi Malaysia',
    gradient: 'linear-gradient(135deg, rgba(245,158,11,0.2), rgba(217,119,6,0.1))',
    border: 'rgba(245,158,11,0.35)',
    glow: 'rgba(245,158,11,0.45)',
    accent: '#f59e0b',
    hoverBg: 'rgba(245,158,11,0.12)',
    cultural: 'Bahasa kebangsaan kami',
  },
  {
    code: 'zh' as Language,
    name: '中文',
    native: '中文（简体）',
    flag: '🇨🇳',
    label: '继续',
    desc: '华语体验',
    gradient: 'linear-gradient(135deg, rgba(239,68,68,0.2), rgba(185,28,28,0.1))',
    border: 'rgba(239,68,68,0.3)',
    glow: 'rgba(239,68,68,0.4)',
    accent: '#ef4444',
    hoverBg: 'rgba(239,68,68,0.12)',
    cultural: '探索马来西亚之美',
  },
];

// Animated cultural words in different languages
const words = [
  { text: 'Malaysia', lang: 'en' },
  { text: '美食', lang: 'zh' },
  { text: 'Makanan', lang: 'bm' },
  { text: '文化', lang: 'zh' },
  { text: 'Culture', lang: 'en' },
  { text: 'Budaya', lang: 'bm' },
  { text: '传统', lang: 'zh' },
  { text: 'Heritage', lang: 'en' },
  { text: 'Warisan', lang: 'bm' },
];

export default function LanguageSelect({ onSelect }: Props) {
  const [hoveredLang, setHoveredLang] = useState<Language | null>(null);
  const [wordIndex, setWordIndex] = useState(0);
  const [particles, setParticles] = useState<{ x: number; y: number; delay: number; size: number }[]>([]);

  useEffect(() => {
    const interval = setInterval(() => {
      setWordIndex(prev => (prev + 1) % words.length);
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const p = Array.from({ length: 20 }, () => ({
      x: Math.random() * 100,
      y: Math.random() * 100,
      delay: Math.random() * 4,
      size: Math.random() * 2.5 + 0.5,
    }));
    setParticles(p);
  }, []);

  const activeGlow = hoveredLang
    ? languages.find(l => l.code === hoveredLang)?.glow
    : 'rgba(245,158,11,0.05)';

  return (
    <div className="relative w-full h-screen overflow-hidden flex flex-col items-center justify-center">
      {/* Background */}
      <div className="absolute inset-0 bg-[#07070f]" />
      <div
        className="absolute inset-0 opacity-12"
        style={{ backgroundImage: 'url(/images/hero-bg.jpg)', backgroundSize: 'cover', backgroundPosition: 'center' }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-black/80" />

      {/* Animated ambient glow responding to hover */}
      <motion.div
        className="absolute inset-0 pointer-events-none"
        animate={{
          background: `radial-gradient(ellipse at 50% 50%, ${activeGlow} 0%, transparent 65%)`,
        }}
        transition={{ duration: 0.6 }}
      />

      {/* Subtle grid */}
      <div className="absolute inset-0 opacity-[0.02] pointer-events-none"
        style={{
          backgroundImage: `linear-gradient(rgba(245,158,11,0.8) 1px, transparent 1px), linear-gradient(90deg, rgba(245,158,11,0.8) 1px, transparent 1px)`,
          backgroundSize: '50px 50px',
        }}
      />

      {/* Particles */}
      {particles.map((p, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full pointer-events-none"
          style={{
            left: `${p.x}%`,
            top: `${p.y}%`,
            width: p.size,
            height: p.size,
            background: i % 3 === 0 ? '#f59e0b' : i % 3 === 1 ? '#3b82f6' : '#ef4444',
          }}
          animate={{ y: [-10, 10, -10], opacity: [0.1, 0.4, 0.1] }}
          transition={{ duration: 4 + p.delay, delay: p.delay, repeat: Infinity, ease: 'easeInOut' }}
        />
      ))}

      {/* Cultural pattern - top right corner */}
      <motion.div
        className="absolute top-8 right-8 opacity-8 pointer-events-none"
        animate={{ rotate: [0, 360] }}
        transition={{ duration: 60, repeat: Infinity, ease: 'linear' }}
      >
        <svg width="100" height="100" viewBox="0 0 100 100">
          {[0, 30, 60, 90, 120, 150].map(a => (
            <g key={a} transform={`rotate(${a} 50 50)`}>
              <ellipse cx="50" cy="20" rx="8" ry="18" fill="none" stroke="#f59e0b" strokeWidth="0.5" />
            </g>
          ))}
          <circle cx="50" cy="50" r="10" fill="none" stroke="#f59e0b" strokeWidth="0.5" />
          <circle cx="50" cy="50" r="4" fill="#f59e0b" opacity="0.3" />
        </svg>
      </motion.div>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center w-full max-w-4xl px-6">
        {/* Animated word display */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="h-8 flex items-center justify-center mb-4"
        >
          <AnimatePresence mode="wait">
            <motion.span
              key={wordIndex}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.4 }}
              className="text-amber-400/40 text-sm font-light tracking-[0.5em] uppercase"
            >
              {words[wordIndex].text}
            </motion.span>
          </AnimatePresence>
        </motion.div>

        {/* Main heading */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.7 }}
          className="text-center mb-10"
        >
          <h2 className="text-4xl sm:text-5xl font-bold text-white mb-2 leading-tight"
            style={{ fontFamily: "'Playfair Display', serif" }}>
            Choose Your{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-amber-400 to-amber-500">
              Language
            </span>
          </h2>
          <div className="flex items-center justify-center gap-3 mt-3">
            <div className="h-px w-12 bg-amber-400/20" />
            <p className="text-white/30 text-sm">Select your preferred language to begin the journey</p>
            <div className="h-px w-12 bg-amber-400/20" />
          </div>
        </motion.div>

        {/* Language cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 w-full max-w-3xl">
          {languages.map((lang, i) => (
            <motion.div
              key={lang.code}
              initial={{ opacity: 0, y: 30, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ delay: 0.5 + i * 0.12, duration: 0.6, ease: 'easeOut' }}
              onMouseEnter={() => setHoveredLang(lang.code)}
              onMouseLeave={() => setHoveredLang(null)}
              onClick={() => onSelect(lang.code)}
              whileHover={{ y: -8, scale: 1.02 }}
              whileTap={{ scale: 0.96 }}
              className="relative cursor-pointer rounded-2xl overflow-hidden"
              style={{
                background: hoveredLang === lang.code ? lang.gradient : 'rgba(255,255,255,0.03)',
                border: `1px solid ${hoveredLang === lang.code ? lang.border : 'rgba(255,255,255,0.07)'}`,
                boxShadow: hoveredLang === lang.code
                  ? `0 0 40px ${lang.glow}, 0 20px 40px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.08)`
                  : '0 4px 20px rgba(0,0,0,0.3)',
                backdropFilter: 'blur(20px)',
                transition: 'all 0.35s ease',
              }}
            >
              {/* Top accent line */}
              <motion.div
                className="absolute top-0 left-0 right-0 h-0.5"
                animate={{
                  background: hoveredLang === lang.code
                    ? `linear-gradient(to right, transparent, ${lang.accent}80, transparent)`
                    : 'transparent',
                }}
                transition={{ duration: 0.3 }}
              />

              {/* Card content */}
              <div className="p-7 flex flex-col items-center gap-4">
                {/* Flag with glow */}
                <motion.div
                  className="relative"
                  animate={hoveredLang === lang.code ? {
                    filter: `drop-shadow(0 0 12px ${lang.glow})`,
                    scale: 1.15,
                  } : {
                    filter: 'none',
                    scale: 1,
                  }}
                  transition={{ duration: 0.3 }}
                >
                  <span className="text-5xl sm:text-6xl">{lang.flag}</span>
                </motion.div>

                {/* Language names */}
                <div className="text-center">
                  <h3 className="text-white font-bold text-xl sm:text-2xl mb-0.5 leading-none"
                    style={{ fontFamily: lang.code === 'zh' ? 'system-ui' : 'inherit' }}>
                    {lang.native}
                  </h3>
                  <p className="text-white/30 text-xs tracking-wider mt-1">{lang.desc}</p>
                </div>

                {/* Divider */}
                <div className="w-full h-px"
                  style={{
                    background: hoveredLang === lang.code
                      ? `linear-gradient(to right, transparent, ${lang.accent}60, transparent)`
                      : 'rgba(255,255,255,0.06)',
                  }}
                />

                {/* Cultural note */}
                <p className="text-white/25 text-xs italic text-center">{lang.cultural}</p>

                {/* CTA button */}
                <motion.div
                  className="w-full py-3 rounded-xl flex items-center justify-center gap-2 font-semibold text-sm tracking-wide transition-all duration-300"
                  style={hoveredLang === lang.code ? {
                    background: `linear-gradient(135deg, ${lang.accent}, ${lang.accent}cc)`,
                    color: '#000',
                    boxShadow: `0 4px 16px ${lang.glow}`,
                  } : {
                    background: 'rgba(255,255,255,0.04)',
                    color: 'rgba(255,255,255,0.35)',
                    border: '1px solid rgba(255,255,255,0.06)',
                  }}
                >
                  <span>{lang.label}</span>
                  <ChevronRight size={14} style={{
                    opacity: hoveredLang === lang.code ? 1 : 0.5,
                    transform: hoveredLang === lang.code ? 'translateX(2px)' : 'none',
                    transition: 'all 0.3s',
                  }} />
                </motion.div>
              </div>

              {/* Corner ornament */}
              {hoveredLang === lang.code && (
                <motion.div
                  initial={{ opacity: 0, scale: 0 }}
                  animate={{ opacity: 0.3, scale: 1 }}
                  className="absolute bottom-3 right-3"
                >
                  <svg width="20" height="20" viewBox="0 0 20 20">
                    <path d="M0 20 L0 8 L2 8 L2 18 L12 18 L12 20 Z" fill={lang.accent} />
                  </svg>
                </motion.div>
              )}
            </motion.div>
          ))}
        </div>

        {/* Bottom tagline */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="mt-10 flex items-center gap-4"
        >
          <div className="h-px w-10 bg-white/08" />
          <p className="text-white/15 text-xs tracking-widest text-center font-light">
            MALAYSIA · TRULY ASIA · 马来西亚 · 真正亚洲
          </p>
          <div className="h-px w-10 bg-white/08" />
        </motion.div>
      </div>

      {/* Corner decorations */}
      <div className="absolute top-0 left-0 w-20 h-20 opacity-15 pointer-events-none">
        <svg viewBox="0 0 80 80" fill="none">
          <path d="M0 0 L30 0 L30 2 L2 2 L2 30 L0 30 Z" fill="#f59e0b" />
          <path d="M8 8 L22 8 L22 10 L10 10 L10 22 L8 22 Z" fill="#f59e0b" />
        </svg>
      </div>
      <div className="absolute top-0 right-0 w-20 h-20 opacity-15 pointer-events-none transform rotate-90">
        <svg viewBox="0 0 80 80" fill="none">
          <path d="M0 0 L30 0 L30 2 L2 2 L2 30 L0 30 Z" fill="#f59e0b" />
        </svg>
      </div>
      <div className="absolute bottom-0 left-0 w-20 h-20 opacity-15 pointer-events-none transform -rotate-90">
        <svg viewBox="0 0 80 80" fill="none">
          <path d="M0 0 L30 0 L30 2 L2 2 L2 30 L0 30 Z" fill="#f59e0b" />
        </svg>
      </div>
      <div className="absolute bottom-0 right-0 w-20 h-20 opacity-15 pointer-events-none transform rotate-180">
        <svg viewBox="0 0 80 80" fill="none">
          <path d="M0 0 L30 0 L30 2 L2 2 L2 30 L0 30 Z" fill="#f59e0b" />
        </svg>
      </div>
    </div>
  );
}
