import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { malaysiaStates, State, Language, translations } from '../data/malaysiaData';
import { Globe, ChevronRight, Search } from 'lucide-react';

interface Props {
  language: Language;
  onStateClick: (state: State) => void;
  onLanguageChange: (lang: Language) => void;
}

// SVG paths for all Malaysian states
const mapPaths: Record<string, string> = {
  perlis: 'M 148 62 L 172 58 L 180 70 L 172 82 L 152 84 L 142 74 Z',
  kedah: 'M 152 84 L 172 82 L 180 70 L 188 80 L 196 76 L 202 92 L 198 108 L 182 120 L 162 124 L 148 112 L 140 96 Z',
  penang: 'M 140 112 L 148 112 L 158 126 L 152 138 L 138 136 L 132 124 Z',
  perak: 'M 162 124 L 182 120 L 198 108 L 214 112 L 224 126 L 228 148 L 220 166 L 200 172 L 178 168 L 162 158 L 155 142 L 158 126 L 148 112 Z',
  selangor: 'M 200 172 L 220 166 L 228 148 L 244 152 L 258 160 L 262 176 L 255 192 L 238 200 L 220 198 L 206 190 Z',
  kl: 'M 220 198 L 238 200 L 255 192 L 262 198 L 258 212 L 244 220 L 230 218 L 220 208 Z',
  putrajaya: 'M 244 220 L 258 212 L 264 218 L 260 226 L 250 228 Z',
  'negeri-sembilan': 'M 230 218 L 244 220 L 250 228 L 260 226 L 266 238 L 260 252 L 246 258 L 230 254 L 220 244 L 220 232 Z',
  melaka: 'M 230 254 L 246 258 L 252 268 L 248 280 L 234 280 L 226 270 L 226 258 Z',
  johor: 'M 220 244 L 230 254 L 226 270 L 234 280 L 248 280 L 256 294 L 248 308 L 234 316 L 218 312 L 206 298 L 204 284 L 210 270 L 218 258 Z',
  pahang: 'M 258 160 L 274 152 L 296 154 L 312 164 L 316 184 L 310 206 L 294 214 L 272 210 L 255 192 L 262 176 Z',
  terengganu: 'M 312 164 L 330 158 L 345 166 L 348 186 L 335 202 L 316 204 L 310 206 Z',
  kelantan: 'M 296 154 L 312 164 L 310 148 L 325 140 L 342 148 L 348 160 L 345 166 L 330 158 L 312 164 L 316 184 L 310 206 L 294 214 L 280 208 L 268 196 L 272 178 L 274 152 Z',
  sabah: 'M 490 105 L 535 90 L 572 96 L 598 118 L 602 142 L 588 168 L 558 182 L 528 184 L 500 172 L 484 150 L 483 130 Z',
  sarawak: 'M 428 145 L 485 130 L 484 150 L 500 172 L 528 184 L 528 205 L 508 220 L 478 222 L 448 215 L 424 198 L 414 175 L 416 158 Z',
  labuan: 'M 447 192 L 458 188 L 463 198 L 456 204 L 445 200 Z',
};

const stateLabels: Record<string, { x: number; y: number; short: string; fontSize?: number }> = {
  perlis: { x: 162, y: 72, short: 'Perlis', fontSize: 5 },
  kedah: { x: 172, y: 100, short: 'Kedah', fontSize: 6 },
  penang: { x: 142, y: 126, short: 'Penang', fontSize: 5 },
  perak: { x: 190, y: 145, short: 'Perak', fontSize: 6.5 },
  selangor: { x: 230, y: 180, short: 'Selangor', fontSize: 5.5 },
  kl: { x: 240, y: 207, short: 'KL', fontSize: 5 },
  putrajaya: { x: 254, y: 220, short: 'Pjy', fontSize: 4 },
  'negeri-sembilan': { x: 242, y: 238, short: 'N.S.', fontSize: 5 },
  melaka: { x: 237, y: 268, short: 'Melaka', fontSize: 5 },
  johor: { x: 228, y: 283, short: 'Johor', fontSize: 6 },
  pahang: { x: 286, y: 183, short: 'Pahang', fontSize: 6.5 },
  terengganu: { x: 329, y: 183, short: 'Terengganu', fontSize: 5 },
  kelantan: { x: 320, y: 158, short: 'Kelantan', fontSize: 5.5 },
  sabah: { x: 543, y: 140, short: 'Sabah', fontSize: 8 },
  sarawak: { x: 472, y: 184, short: 'Sarawak', fontSize: 7.5 },
  labuan: { x: 454, y: 196, short: 'Labuan', fontSize: 3.5 },
};

export default function MapExplorer({ language, onStateClick, onLanguageChange }: Props) {
  const [hoveredState, setHoveredState] = useState<string | null>(null);
  const [tooltip, setTooltip] = useState<{ x: number; y: number; state: State } | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [particles, setParticles] = useState<{ x: number; y: number; size: number; delay: number; speed: number }[]>([]);
  const svgContainerRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const t = translations[language];

  useEffect(() => {
    const p = Array.from({ length: 30 }, () => ({
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 2 + 0.5,
      delay: Math.random() * 5,
      speed: Math.random() * 4 + 3,
    }));
    setParticles(p);
  }, []);

  const getStateName = (state: State) => {
    if (language === 'bm') return state.nameBM;
    if (language === 'zh') return state.nameZH;
    return state.name;
  };

  const handleMouseMove = (e: React.MouseEvent<SVGPathElement>, state: State) => {
    const container = svgContainerRef.current;
    if (container) {
      const rect = container.getBoundingClientRect();
      setTooltip({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top - 100,
        state,
      });
    }
  };

  const isHighlighted = (stateId: string) => {
    if (!searchTerm) return true;
    const state = malaysiaStates.find(s => s.id === stateId);
    if (!state) return false;
    return getStateName(state).toLowerCase().includes(searchTerm.toLowerCase());
  };

  return (
    <div className="relative w-full h-screen overflow-hidden bg-[#04040c]">
      {/* Ambient background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-[#04040c] via-[#080818] to-[#04040c]" />
        {/* Floating ambient orbs */}
        <div className="absolute top-20 left-1/4 w-80 h-80 rounded-full opacity-8 blur-3xl pointer-events-none"
          style={{ background: 'radial-gradient(circle, rgba(245,158,11,0.2), transparent)' }} />
        <div className="absolute bottom-20 right-1/4 w-96 h-96 rounded-full opacity-8 blur-3xl pointer-events-none"
          style={{ background: 'radial-gradient(circle, rgba(16,185,129,0.15), transparent)' }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] rounded-full opacity-5 blur-3xl pointer-events-none"
          style={{ background: 'radial-gradient(ellipse, rgba(59,130,246,0.2), transparent)' }} />
      </div>

      {/* Grid pattern */}
      <div className="absolute inset-0 opacity-[0.025] pointer-events-none"
        style={{
          backgroundImage: `linear-gradient(rgba(245,158,11,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(245,158,11,0.5) 1px, transparent 1px)`,
          backgroundSize: '60px 60px',
        }}
      />

      {/* Floating particles */}
      {particles.map((p, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full pointer-events-none"
          style={{
            left: `${p.x}%`,
            top: `${p.y}%`,
            width: p.size,
            height: p.size,
            background: i % 3 === 0 ? '#f59e0b' : i % 3 === 1 ? '#10b981' : '#3b82f6',
          }}
          animate={{ y: [-15, 15, -15], opacity: [0.1, 0.4, 0.1] }}
          transition={{ duration: p.speed, delay: p.delay, repeat: Infinity, ease: 'easeInOut' }}
        />
      ))}

      {/* Header */}
      <div className="absolute top-0 left-0 right-0 z-30 px-6 py-4"
        style={{ background: 'linear-gradient(to bottom, rgba(4,4,12,0.95) 0%, rgba(4,4,12,0) 100%)' }}>
        <div className="flex items-center justify-between">
          {/* Logo */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-3"
          >
            <div className="relative">
              <div
                className="w-9 h-9 rounded-xl flex items-center justify-center"
                style={{
                  background: 'linear-gradient(135deg, #f59e0b, #d97706)',
                  boxShadow: '0 0 15px rgba(245,158,11,0.4)',
                }}
              >
                <Globe size={16} className="text-black" />
              </div>
              <div className="absolute inset-0 rounded-xl animate-ping opacity-20"
                style={{ background: '#f59e0b' }} />
            </div>
            <div>
              <h1 className="text-white font-bold text-base leading-none">Malaysia</h1>
              <p className="text-amber-400/50 text-xs font-light tracking-widest">TRULY ASIA</p>
            </div>
          </motion.div>

          <div className="flex items-center gap-3">
            {/* Search */}
            <div className="relative hidden sm:flex items-center">
              <Search size={12} className="absolute left-3 text-white/30" />
              <input
                type="text"
                placeholder="Search state..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="pl-8 pr-3 py-1.5 rounded-lg text-xs text-white/60 placeholder-white/20 outline-none"
                style={{
                  background: 'rgba(255,255,255,0.05)',
                  border: '1px solid rgba(255,255,255,0.08)',
                  backdropFilter: 'blur(10px)',
                }}
              />
            </div>

            {/* Language buttons */}
            <div className="flex items-center gap-1 p-1 rounded-xl"
              style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.06)' }}>
              {(['en', 'bm', 'zh'] as Language[]).map((lang) => (
                <button
                  key={lang}
                  onClick={() => onLanguageChange(lang)}
                  className={`px-3 py-1 rounded-lg text-xs font-medium transition-all duration-200 ${
                    language === lang ? 'text-black' : 'text-white/40 hover:text-white/70'
                  }`}
                  style={language === lang ? {
                    background: 'linear-gradient(135deg, #f59e0b, #d97706)',
                    boxShadow: '0 0 10px rgba(245,158,11,0.4)',
                  } : {}}
                >
                  {lang === 'en' ? 'EN' : lang === 'bm' ? 'BM' : '中文'}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Title */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-center mt-3"
        >
          <h2 className="text-white/80 text-sm font-light tracking-widest uppercase">
            {t.clickState}
          </h2>
        </motion.div>
      </div>

      {/* Map Area */}
      <div
        ref={svgContainerRef}
        className="absolute inset-0 flex items-center justify-center"
        style={{ paddingTop: '80px', paddingBottom: '60px' }}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2, duration: 0.8 }}
          className="relative w-full h-full flex items-center justify-center"
        >
          <svg
            ref={svgRef}
            viewBox="80 50 570 300"
            className="w-full h-full drop-shadow-2xl"
            style={{ maxWidth: '98vw', maxHeight: '72vh', filter: 'drop-shadow(0 0 30px rgba(245,158,11,0.05))' }}
            onMouseLeave={() => { setHoveredState(null); setTooltip(null); }}
          >
            <defs>
              {/* Glow filters */}
              <filter id="softGlow" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="2.5" result="coloredBlur" />
                <feMerge>
                  <feMergeNode in="coloredBlur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
              <filter id="strongGlow" x="-30%" y="-30%" width="160%" height="160%">
                <feGaussianBlur stdDeviation="5" result="coloredBlur" />
                <feMerge>
                  <feMergeNode in="coloredBlur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
              <filter id="labelGlow">
                <feGaussianBlur stdDeviation="1.5" result="coloredBlur" />
                <feMerge>
                  <feMergeNode in="coloredBlur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>

              {/* Radial gradients for each state */}
              {malaysiaStates.map(state => [
                <radialGradient key={`fill-${state.id}`} id={`fill-${state.id}`} cx="50%" cy="50%" r="70%">
                  <stop offset="0%" stopColor={state.accentColor} stopOpacity="0.65" />
                  <stop offset="100%" stopColor={state.accentColor} stopOpacity="0.2" />
                </radialGradient>,
                <radialGradient key={`base-${state.id}`} id={`base-${state.id}`} cx="50%" cy="50%" r="70%">
                  <stop offset="0%" stopColor={state.accentColor} stopOpacity="0.22" />
                  <stop offset="100%" stopColor={state.accentColor} stopOpacity="0.06" />
                </radialGradient>
              ])}

              {/* Ocean gradient */}
              <linearGradient id="oceanGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#0c1a3a" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#0a2f4a" stopOpacity="0.2" />
              </linearGradient>
            </defs>

            {/* Region separators / visual guides */}
            {/* South China Sea label */}
            <text x="390" y="200" fill="rgba(59,130,246,0.12)" fontSize="11" textAnchor="middle"
              fontFamily="serif" fontStyle="italic" letterSpacing="1">
              South China Sea
            </text>
            {/* Connection line between peninsular and east */}
            <line x1="360" y1="180" x2="415" y2="165" stroke="rgba(245,158,11,0.06)"
              strokeWidth="1" strokeDasharray="6 4" />

            {/* Regional labels */}
            <text x="205" y="60" fill="rgba(255,255,255,0.12)" fontSize="7" textAnchor="middle"
              fontFamily="sans-serif" fontWeight="300" letterSpacing="2">
              PENINSULAR MALAYSIA
            </text>
            <text x="515" y="62" fill="rgba(255,255,255,0.12)" fontSize="7" textAnchor="middle"
              fontFamily="sans-serif" fontWeight="300" letterSpacing="2">
              EAST MALAYSIA
            </text>

            {/* Render states */}
            {malaysiaStates.map((state) => {
              const path = mapPaths[state.id];
              if (!path) return null;
              const isHovered = hoveredState === state.id;
              const highlighted = isHighlighted(state.id);
              const label = stateLabels[state.id];
              const fontSize = label?.fontSize || 6;
              const isSmall = ['labuan', 'putrajaya'].includes(state.id);

              return (
                <g key={state.id} style={{ opacity: highlighted ? 1 : 0.25, transition: 'opacity 0.3s ease' }}>
                  {/* Base fill */}
                  <path
                    d={path}
                    fill={isHovered ? `url(#fill-${state.id})` : `url(#base-${state.id})`}
                    stroke={isHovered ? state.accentColor : `${state.accentColor}55`}
                    strokeWidth={isHovered ? 1.8 : 0.7}
                    className="cursor-pointer map-state"
                    filter={isHovered ? 'url(#strongGlow)' : undefined}
                    onMouseEnter={() => setHoveredState(state.id)}
                    onMouseMove={(e) => handleMouseMove(e, state)}
                    onMouseLeave={() => { setHoveredState(null); setTooltip(null); }}
                    onClick={() => onStateClick(state)}
                  />

                  {/* Animated glow ring on hover */}
                  {isHovered && (
                    <motion.path
                      d={path}
                      fill="none"
                      stroke={state.accentColor}
                      strokeWidth="4"
                      filter="url(#strongGlow)"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: [0.3, 0.7, 0.3] }}
                      transition={{ duration: 1.5, repeat: Infinity }}
                      style={{ pointerEvents: 'none' }}
                    />
                  )}

                  {/* Inner glow fill on hover */}
                  {isHovered && (
                    <motion.path
                      d={path}
                      fill={state.accentColor}
                      opacity={0.08}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: [0.05, 0.12, 0.05] }}
                      transition={{ duration: 2, repeat: Infinity }}
                      style={{ pointerEvents: 'none' }}
                    />
                  )}

                  {/* State label */}
                  {label && !isSmall && (
                    <text
                      x={label.x}
                      y={label.y}
                      fill={isHovered ? '#ffffff' : 'rgba(255,255,255,0.55)'}
                      fontSize={fontSize}
                      textAnchor="middle"
                      fontWeight={isHovered ? '700' : '400'}
                      fontFamily="sans-serif"
                      filter={isHovered ? 'url(#labelGlow)' : undefined}
                      style={{ pointerEvents: 'none', transition: 'all 0.3s ease', letterSpacing: '0.3px' }}
                    >
                      {label.short}
                    </text>
                  )}

                  {/* Pulse dot */}
                  {!isSmall && label && (
                    <motion.circle
                      cx={label.x}
                      cy={label.y + fontSize * 0.8}
                      r={isHovered ? 2 : 1.2}
                      fill={state.accentColor}
                      opacity={isHovered ? 1 : 0.5}
                      animate={isHovered ? { r: [1.5, 2.5, 1.5], opacity: [0.7, 1, 0.7] } : {}}
                      transition={{ duration: 1, repeat: Infinity }}
                      style={{ pointerEvents: 'none' }}
                    />
                  )}
                </g>
              );
            })}

            {/* Map border ornament */}
            <rect x="82" y="52" width="566" height="296" fill="none"
              stroke="rgba(245,158,11,0.07)" strokeWidth="0.5" rx="3" />
            <rect x="84" y="54" width="562" height="292" fill="none"
              stroke="rgba(245,158,11,0.04)" strokeWidth="0.3" rx="2" />
          </svg>

          {/* Floating state tooltip */}
          <AnimatePresence>
            {tooltip && (
              <motion.div
                key="tooltip"
                initial={{ opacity: 0, scale: 0.85, y: 8 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.85, y: 8 }}
                transition={{ duration: 0.15 }}
                className="absolute pointer-events-none z-40 backdrop-blur-2xl rounded-2xl p-4"
                style={{
                  left: Math.min(tooltip.x + 16, (svgContainerRef.current?.clientWidth || 700) - 220),
                  top: Math.max(tooltip.y, 10),
                  background: 'rgba(8, 8, 20, 0.95)',
                  border: `1px solid ${tooltip.state.accentColor}40`,
                  boxShadow: `0 0 25px ${tooltip.state.glowColor}, 0 8px 32px rgba(0,0,0,0.6)`,
                  minWidth: '180px',
                }}
              >
                {/* Accent line */}
                <div className="absolute top-0 left-4 right-4 h-px"
                  style={{ background: `linear-gradient(to right, transparent, ${tooltip.state.accentColor}80, transparent)` }} />

                <div className="flex items-center gap-2 mb-2">
                  <motion.div
                    className="w-2.5 h-2.5 rounded-full"
                    style={{ background: tooltip.state.accentColor }}
                    animate={{ scale: [1, 1.3, 1] }}
                    transition={{ duration: 1, repeat: Infinity }}
                  />
                  <p className="text-white font-bold text-sm">
                    {language === 'bm' ? tooltip.state.nameBM : language === 'zh' ? tooltip.state.nameZH : tooltip.state.name}
                  </p>
                </div>
                <p className="text-white/35 text-xs mb-3 ml-4">{tooltip.state.capital}</p>
                
                <div className="ml-4 space-y-1.5">
                  <div className="flex items-center gap-2">
                    <span className="text-xs" style={{ color: tooltip.state.accentColor }}>🍽️</span>
                    <span className="text-white/50 text-xs">{tooltip.state.foods.length} famous dishes</span>
                  </div>
                  <p className="text-white/25 text-xs italic leading-relaxed">{tooltip.state.culturalTheme}</p>
                </div>

                <div className="mt-3 flex items-center gap-1 ml-4"
                  style={{ color: tooltip.state.accentColor }}>
                  <span className="text-xs font-medium">Click to explore</span>
                  <ChevronRight size={10} />
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>

      {/* Bottom bar */}
      <div className="absolute bottom-0 left-0 right-0 z-20 px-8 py-4"
        style={{ background: 'linear-gradient(to top, rgba(4,4,12,0.9) 0%, transparent 100%)' }}>
        <div className="flex items-center justify-between">
          {/* Stats */}
          <div className="flex items-center gap-8">
            {[
              { value: '16', label: 'States & Federal Territories' },
              { value: '80+', label: 'Iconic Dishes' },
              { value: '3', label: 'Distinct Cultures' },
            ].map(item => (
              <div key={item.label} className="hidden sm:block">
                <p className="text-amber-400 font-bold text-xl leading-none">{item.value}</p>
                <p className="text-white/25 text-xs mt-0.5">{item.label}</p>
              </div>
            ))}
          </div>

          {/* Quick navigation */}
          <div className="flex items-center gap-2">
            {[
              { label: 'Peninsular', color: '#f59e0b' },
              { label: 'East Malaysia', color: '#0d9488' },
              { label: 'Federal', color: '#6366f1' },
            ].map(item => (
              <div key={item.label} className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-sm" style={{ background: item.color, opacity: 0.7 }} />
                <span className="text-white/25 text-xs">{item.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* State list sidebar - visible on larger screens */}
      <div className="absolute left-4 top-1/2 -translate-y-1/2 z-20 hidden xl:flex flex-col gap-0.5 max-h-[60vh] overflow-y-auto"
        style={{ scrollbarWidth: 'none' }}>
        {malaysiaStates.map((state) => (
          <motion.button
            key={state.id}
            onClick={() => onStateClick(state)}
            whileHover={{ x: 6 }}
            className="group flex items-center gap-2 px-2 py-1.5 rounded-lg text-left"
            style={{ opacity: isHighlighted(state.id) ? 1 : 0.3 }}
          >
            <motion.div
              className="w-1.5 h-1.5 rounded-full flex-shrink-0"
              style={{ background: state.accentColor }}
              animate={hoveredState === state.id ? { scale: [1, 1.5, 1] } : {}}
              transition={{ duration: 0.5 }}
            />
            <span className="text-white/30 text-xs group-hover:text-white/70 transition-colors whitespace-nowrap font-light">
              {getStateName(state)}
            </span>
          </motion.button>
        ))}
      </div>

      {/* Corner decorations */}
      {[
        'top-4 left-4',
        'top-4 right-4 rotate-90',
        'bottom-16 left-4 -rotate-90',
        'bottom-16 right-4 rotate-180',
      ].map((pos, i) => (
        <div key={i} className={`absolute ${pos} w-8 h-8 opacity-20 pointer-events-none`}>
          <svg viewBox="0 0 32 32" fill="none">
            <path d="M0 0 L14 0 L14 1 L1 1 L1 14 L0 14 Z" fill="#f59e0b" />
            <path d="M3 3 L10 3 L10 4 L4 4 L4 10 L3 10 Z" fill="#f59e0b" />
          </svg>
        </div>
      ))}
    </div>
  );
}
