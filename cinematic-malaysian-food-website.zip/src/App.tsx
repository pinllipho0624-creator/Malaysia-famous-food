import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import WelcomeScreen from './components/WelcomeScreen';
import LanguageSelect from './components/LanguageSelect';
import MapExplorer from './components/MapExplorer';
import StatePanel from './components/StatePanel';
import FoodDetail from './components/FoodDetail';
import { Language, State, Food } from './data/malaysiaData';

type Screen = 'welcome' | 'language' | 'map' | 'state' | 'food';

// Page transition variants
const pageVariants = {
  initial: { opacity: 0, scale: 0.99 },
  animate: { opacity: 1, scale: 1 },
  exit: { opacity: 0, scale: 1.005 },
};

const pageTransition = {
  duration: 0.5,
  ease: 'easeInOut' as const,
};

export default function App() {
  const [screen, setScreen] = useState<Screen>('welcome');
  const [language, setLanguage] = useState<Language>('en');
  const [selectedState, setSelectedState] = useState<State | null>(null);
  const [selectedFood, setSelectedFood] = useState<Food | null>(null);

  const handleWelcomeEnter = () => setScreen('language');

  const handleLanguageSelect = (lang: Language) => {
    setLanguage(lang);
    setScreen('map');
  };

  const handleStateClick = (state: State) => {
    setSelectedState(state);
    setScreen('state');
  };

  const handleFoodClick = (food: Food) => {
    setSelectedFood(food);
    setScreen('food');
  };

  const handleBackToMap = () => {
    setSelectedState(null);
    setScreen('map');
  };

  const handleBackToState = () => {
    setSelectedFood(null);
    setScreen('state');
  };

  return (
    <div className="relative w-full min-h-screen overflow-hidden bg-[#05050d]">
      <AnimatePresence mode="wait">
        {screen === 'welcome' && (
          <motion.div
            key="welcome"
            variants={pageVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            transition={pageTransition}
            className="absolute inset-0"
          >
            <WelcomeScreen onEnter={handleWelcomeEnter} language={language} />
          </motion.div>
        )}

        {screen === 'language' && (
          <motion.div
            key="language"
            variants={pageVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            transition={pageTransition}
            className="absolute inset-0"
          >
            <LanguageSelect onSelect={handleLanguageSelect} />
          </motion.div>
        )}

        {screen === 'map' && (
          <motion.div
            key="map"
            variants={pageVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            transition={pageTransition}
            className="absolute inset-0"
          >
            <MapExplorer
              language={language}
              onStateClick={handleStateClick}
              onLanguageChange={setLanguage}
            />
          </motion.div>
        )}

        {screen === 'state' && selectedState && (
          <motion.div
            key={`state-${selectedState.id}`}
            variants={pageVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            transition={pageTransition}
            className="absolute inset-0"
          >
            <StatePanel
              state={selectedState}
              language={language}
              onBack={handleBackToMap}
              onFoodClick={handleFoodClick}
            />
          </motion.div>
        )}

        {screen === 'food' && selectedFood && selectedState && (
          <motion.div
            key={`food-${selectedFood.id}`}
            variants={pageVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            transition={pageTransition}
            className="absolute inset-0"
          >
            <FoodDetail
              food={selectedFood}
              state={selectedState}
              language={language}
              onBack={handleBackToState}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Global cinematic overlay on transitions */}
      <div className="pointer-events-none fixed inset-0 z-50">
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-400/20 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-400/10 to-transparent" />
      </div>
    </div>
  );
}
