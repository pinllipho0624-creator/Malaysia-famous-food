import { motion } from 'framer-motion';
import { Language } from '../data/malaysiaData';
import { Globe } from 'lucide-react';

interface NavbarProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  onLogoClick: () => void;
}

const langLabels: Record<Language, string> = {
  en: 'EN',
  ms: 'MY',
  zh: '中文',
};

export default function Navbar({ language, onLanguageChange, onLogoClick }: NavbarProps) {
  const langs: Language[] = ['en', 'ms', 'zh'];

  return (
    <motion.nav
      initial={{ y: -60, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: 'easeOut' }}
      className="fixed top-0 left-0 right-0 z-40 px-4 md:px-8 py-3"
    >
      <div
        className="max-w-6xl mx-auto flex items-center justify-between rounded-2xl px-5 py-3"
        style={{
          background: 'rgba(255,255,255,0.85)',
          backdropFilter: 'blur(20px)',
          boxShadow: '0 4px 24px rgba(0,0,0,0.08), 0 0 0 1px rgba(255,255,255,0.6)',
        }}
      >
        {/* Logo */}
        <button
          onClick={onLogoClick}
          className="flex items-center gap-2 cursor-pointer group"
        >
          <motion.div
            whileHover={{ rotate: 15 }}
            transition={{ duration: 0.3 }}
            className="text-2xl"
          >
            🌺
          </motion.div>
          <div>
            <div className="font-bold text-gray-800 text-sm leading-none">
              Rasa
              <span style={{
                background: 'linear-gradient(135deg, #F59E0B, #EF4444)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
              }}>
                Malaysia
              </span>
            </div>
            <div className="text-gray-400 text-xs leading-none">Food & Culture</div>
          </div>
        </button>

        {/* Center tagline - hidden on mobile */}
        <div className="hidden md:block text-center">
          <p className="text-gray-400 text-xs tracking-widest uppercase">
            Food · Culture · Soul
          </p>
        </div>

        {/* Language switcher */}
        <div className="flex items-center gap-1">
          <Globe size={14} className="text-gray-400 mr-1" />
          {langs.map(lang => (
            <motion.button
              key={lang}
              onClick={() => onLanguageChange(lang)}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-3 py-1.5 rounded-xl text-xs font-semibold cursor-pointer transition-all duration-200"
              style={
                language === lang
                  ? {
                      background: 'linear-gradient(135deg, #F59E0B, #EF4444)',
                      color: 'white',
                      boxShadow: '0 2px 8px rgba(245,158,11,0.4)',
                    }
                  : {
                      background: 'transparent',
                      color: '#9CA3AF',
                    }
              }
            >
              {langLabels[lang]}
            </motion.button>
          ))}
        </div>
      </div>
    </motion.nav>
  );
}
