import { motion, AnimatePresence, useMotionValue, useTransform } from 'framer-motion';
import { useState, useRef } from 'react';
import { Language } from '../data/malaysiaData';

interface WelcomeScreenProps {
  onLanguageSelect: (lang: Language) => void;
}

const languages = [
  { code: 'en' as Language, label: 'English', native: 'English', flag: '🇬🇧', sub: 'Continue in English' },
  { code: 'ms' as Language, label: 'Bahasa Melayu', native: 'Melayu', flag: '🇲🇾', sub: 'Teruskan dalam Bahasa Melayu' },
  { code: 'zh' as Language, label: 'Chinese', native: '中文', flag: '🀄', sub: '以中文继续' },
];

const FOOD_HIGHLIGHTS = [
  { emoji: '🍜', label: 'Char Kway Teow', state: 'Penang' },
  { emoji: '🍲', label: 'Assam Laksa', state: 'Penang' },
  { emoji: '🍚', label: 'Nasi Lemak', state: 'Nationwide' },
  { emoji: '🌶️', label: 'Rendang', state: 'Nationwide' },
  { emoji: '🐟', label: 'Hinava', state: 'Sabah' },
  { emoji: '💙', label: 'Nasi Kerabu', state: 'Kelantan' },
];

export default function WelcomeScreen({ onLanguageSelect }: WelcomeScreenProps) {
  const [showLanguages, setShowLanguages] = useState(false);
  const [selectedLang, setSelectedLang] = useState<Language | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  const rotateX = useTransform(mouseY, [-300, 300], [4, -4]);
  const rotateY = useTransform(mouseX, [-300, 300], [-4, 4]);

  const handleMouseMove = (e: React.MouseEvent) => {
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;
    mouseX.set(e.clientX - rect.left - rect.width / 2);
    mouseY.set(e.clientY - rect.top - rect.height / 2);
  };

  const handleEnter = () => setShowLanguages(true);

  const handleLangSelect = (lang: Language) => {
    setSelectedLang(lang);
    setTimeout(() => onLanguageSelect(lang), 900);
  };

  return (
    <div
      ref={containerRef}
      className="relative w-full h-screen overflow-hidden"
      onMouseMove={handleMouseMove}
    >
      {/* Cinematic hero background */}
      <motion.div
        className="absolute inset-0 bg-cover bg-center scale-105"
        style={{
          backgroundImage: 'url(/images/hero-bg.jpg)',
          rotateX,
          rotateY,
        }}
      />

      {/* Multi-layer overlay for depth */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/20 to-black/90" />
      <div className="absolute inset-0 bg-gradient-to-r from-black/50 via-transparent to-black/50" />
      <div className="absolute inset-0" style={{
        background: 'radial-gradient(ellipse at center, rgba(245,158,11,0.05) 0%, transparent 70%)',
      }} />

      {/* Batik geometric overlay */}
      <div className="absolute inset-0 opacity-[0.04] pointer-events-none" style={{
        backgroundImage: `url("data:image/svg+xml,%3Csvg width='80' height='80' viewBox='0 0 80 80' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23FFD700'%3E%3Ccircle cx='40' cy='40' r='20' fill='none' stroke='%23FFD700' stroke-width='2'/%3E%3Ccircle cx='40' cy='40' r='10' fill='none' stroke='%23FFD700' stroke-width='1'/%3E%3Cline x1='20' y1='40' x2='60' y2='40' stroke='%23FFD700' stroke-width='0.5'/%3E%3Cline x1='40' y1='20' x2='40' y2='60' stroke='%23FFD700' stroke-width='0.5'/%3E%3C/g%3E%3C/svg%3E")`,
        backgroundSize: '80px 80px',
      }} />

      {/* Animated orbs - lantern glow effects */}
      <motion.div
        className="absolute pointer-events-none rounded-full blur-3xl"
        style={{
          background: 'radial-gradient(circle, rgba(251,191,36,0.2) 0%, transparent 70%)',
          width: '40vw',
          height: '40vw',
          left: '10%',
          top: '20%',
        }}
        animate={{ scale: [1, 1.3, 1], x: [0, 20, 0], opacity: [0.6, 1, 0.6] }}
        transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
      />
      <motion.div
        className="absolute pointer-events-none rounded-full blur-3xl"
        style={{
          background: 'radial-gradient(circle, rgba(239,68,68,0.15) 0%, transparent 70%)',
          width: '30vw',
          height: '30vw',
          right: '5%',
          bottom: '25%',
        }}
        animate={{ scale: [1.2, 1, 1.2], x: [0, -15, 0], opacity: [0.4, 0.8, 0.4] }}
        transition={{ duration: 7, repeat: Infinity, ease: 'easeInOut', delay: 1.5 }}
      />
      <motion.div
        className="absolute pointer-events-none rounded-full blur-3xl"
        style={{
          background: 'radial-gradient(circle, rgba(52,211,153,0.1) 0%, transparent 70%)',
          width: '25vw',
          height: '25vw',
          left: '40%',
          bottom: '10%',
        }}
        animate={{ scale: [1, 1.4, 1], opacity: [0.3, 0.6, 0.3] }}
        transition={{ duration: 9, repeat: Infinity, ease: 'easeInOut', delay: 3 }}
      />

      {/* Floating micro-particles */}
      {[...Array(18)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full pointer-events-none"
          style={{
            width: Math.random() > 0.5 ? 2 : 4,
            height: Math.random() > 0.5 ? 2 : 4,
            left: `${5 + Math.random() * 90}%`,
            top: `${5 + Math.random() * 90}%`,
            background: i % 3 === 0 ? '#FCD34D' : i % 3 === 1 ? '#EF4444' : '#34D399',
          }}
          animate={{
            y: [0, -(30 + Math.random() * 50), 0],
            x: [0, (Math.random() - 0.5) * 30, 0],
            opacity: [0, 0.8, 0],
            scale: [0.5, 1.5, 0.5],
          }}
          transition={{
            duration: 4 + Math.random() * 4,
            repeat: Infinity,
            delay: Math.random() * 5,
            ease: 'easeInOut',
          }}
        />
      ))}

      {/* Top decorative stripe */}
      <motion.div
        className="absolute top-0 left-0 right-0 h-1"
        style={{ background: 'linear-gradient(90deg, #F59E0B, #EF4444, #2D6A4F, #2E86AB, #8B4513, #F59E0B)' }}
        animate={{ backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'] }}
        transition={{ duration: 5, repeat: Infinity }}
      />

      {/* Main Content */}
      <div className="relative z-10 flex flex-col items-center justify-center h-full px-6 text-center">
        <AnimatePresence mode="wait">
          {!showLanguages ? (
            <motion.div
              key="welcome"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0, y: -30, scale: 0.96 }}
              transition={{ duration: 0.7 }}
              className="flex flex-col items-center max-w-2xl w-full"
            >
              {/* Animated logo */}
              <motion.div
                initial={{ opacity: 0, scale: 0.3, rotate: -30 }}
                animate={{ opacity: 1, scale: 1, rotate: 0 }}
                transition={{ delay: 0.2, duration: 1, type: 'spring', bounce: 0.5 }}
                className="mb-8 relative"
              >
                {/* Rotating rings */}
                <motion.div
                  className="absolute rounded-full border border-amber-400/30"
                  style={{ width: 100, height: 100, left: -10, top: -10 }}
                  animate={{ rotate: 360 }}
                  transition={{ duration: 15, repeat: Infinity, ease: 'linear' }}
                />
                <motion.div
                  className="absolute rounded-full border border-red-400/20"
                  style={{ width: 120, height: 120, left: -20, top: -20 }}
                  animate={{ rotate: -360 }}
                  transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
                />
                {/* Center icon */}
                <div className="relative w-20 h-20 rounded-full flex items-center justify-center"
                  style={{
                    background: 'linear-gradient(135deg, rgba(245,158,11,0.2), rgba(239,68,68,0.15))',
                    border: '1px solid rgba(245,158,11,0.4)',
                    backdropFilter: 'blur(10px)',
                  }}>
                  <motion.span
                    className="text-4xl"
                    animate={{ rotate: [0, 10, -10, 0] }}
                    transition={{ duration: 4, repeat: Infinity, delay: 1 }}
                  >
                    🌺
                  </motion.span>
                </div>
              </motion.div>

              {/* Title */}
              <motion.div
                initial={{ opacity: 0, y: 40 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5, duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
              >
                <p className="text-amber-300/70 text-xs font-semibold tracking-[0.4em] uppercase mb-4">
                  ✦ An Immersive Food & Culture Experience ✦
                </p>
                <h1 className="font-black text-white leading-none mb-2"
                  style={{ fontSize: 'clamp(3rem, 10vw, 6rem)' }}>
                  Welcome to
                </h1>
                <h1
                  className="font-black leading-none mb-8"
                  style={{
                    fontSize: 'clamp(3.5rem, 12vw, 7rem)',
                    background: 'linear-gradient(135deg, #FCD34D 0%, #F97316 50%, #EF4444 100%)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    backgroundClip: 'text',
                    filter: 'drop-shadow(0 0 30px rgba(249,115,22,0.3))',
                  }}>
                  Malaysia
                </h1>

                {/* Food previews */}
                <div className="flex flex-wrap justify-center gap-2 mb-8">
                  {FOOD_HIGHLIGHTS.map((food, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, scale: 0.7 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.8 + i * 0.1 }}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-full"
                      style={{
                        background: 'rgba(255,255,255,0.08)',
                        border: '1px solid rgba(255,255,255,0.12)',
                        backdropFilter: 'blur(10px)',
                      }}
                    >
                      <span className="text-base">{food.emoji}</span>
                      <span className="text-white/70 text-xs font-medium">{food.label}</span>
                      <span className="text-amber-400/60 text-xs">· {food.state}</span>
                    </motion.div>
                  ))}
                </div>
              </motion.div>

              {/* CTA Button */}
              <motion.button
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.1, duration: 0.6 }}
                onClick={handleEnter}
                className="group relative px-12 py-4 rounded-full cursor-pointer overflow-hidden"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.97 }}
              >
                {/* Button gradient bg */}
                <div className="absolute inset-0 rounded-full"
                  style={{ background: 'linear-gradient(135deg, #F59E0B 0%, #EF4444 100%)' }} />
                {/* Hover shimmer */}
                <motion.div
                  className="absolute inset-0 rounded-full opacity-0 group-hover:opacity-100"
                  style={{ background: 'linear-gradient(135deg, #FBBF24 0%, #F97316 100%)' }}
                  transition={{ duration: 0.3 }}
                />
                {/* Pulse ring */}
                <motion.div
                  className="absolute inset-0 rounded-full border-2 border-amber-300"
                  animate={{ scale: [1, 1.2, 1], opacity: [0.8, 0, 0.8] }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
                <span className="relative text-white font-bold text-lg tracking-wide flex items-center gap-2">
                  <span>Begin the Journey</span>
                  <motion.span
                    animate={{ x: [0, 4, 0] }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                  >→</motion.span>
                </span>
              </motion.button>

              {/* Bottom tagline */}
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1.4 }}
                className="mt-6 text-white/30 text-xs tracking-widest uppercase"
              >
                Food · Culture · Soul · 13 States · 50+ Dishes
              </motion.p>
            </motion.div>
          ) : (
            <motion.div
              key="language"
              initial={{ opacity: 0, y: 40, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -30 }}
              transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
              className="flex flex-col items-center max-w-2xl w-full"
            >
              {/* Back indicator */}
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="mb-8 text-center"
              >
                <div className="flex justify-center mb-4">
                  <span className="text-4xl">🌺</span>
                </div>
                <p className="text-amber-300/60 text-xs tracking-[0.4em] uppercase font-semibold mb-3">
                  ✦ Choose Your Language ✦
                </p>
                <h2 className="text-white font-bold mb-1" style={{ fontSize: 'clamp(2rem, 6vw, 3rem)' }}>
                  How would you like
                </h2>
                <h2 style={{
                  fontSize: 'clamp(2rem, 6vw, 3rem)',
                  fontWeight: 800,
                  background: 'linear-gradient(135deg, #FCD34D, #F97316)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  backgroundClip: 'text',
                }}>
                  to explore?
                </h2>
              </motion.div>

              {/* Language cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 w-full max-w-xl">
                {languages.map((lang, i) => (
                  <motion.button
                    key={lang.code}
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.25 + i * 0.12, duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
                    onClick={() => handleLangSelect(lang.code)}
                    className="group relative p-6 rounded-2xl overflow-hidden cursor-pointer text-left"
                    whileHover={{ scale: 1.04, y: -4 }}
                    whileTap={{ scale: 0.97 }}
                  >
                    {/* Glass background */}
                    <motion.div
                      className="absolute inset-0 rounded-2xl"
                      style={{
                        background: selectedLang === lang.code
                          ? 'linear-gradient(135deg, rgba(245,158,11,0.35), rgba(239,68,68,0.25))'
                          : 'rgba(255,255,255,0.07)',
                        border: `1px solid ${selectedLang === lang.code ? 'rgba(251,191,36,0.6)' : 'rgba(255,255,255,0.12)'}`,
                        backdropFilter: 'blur(20px)',
                      }}
                    />
                    {/* Hover shimmer */}
                    <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                      style={{ background: 'rgba(255,255,255,0.05)' }} />

                    <div className="relative flex flex-col items-center text-center gap-2">
                      <motion.span
                        className="text-4xl"
                        animate={selectedLang === lang.code ? { rotate: [0, 10, -10, 0], scale: [1, 1.2, 1] } : {}}
                        transition={{ duration: 0.5 }}
                      >
                        {lang.flag}
                      </motion.span>
                      <span className="text-white font-bold text-xl">{lang.native}</span>
                      <span className="text-white/40 text-xs">{lang.sub}</span>
                    </div>

                    {/* Selected pulse */}
                    {selectedLang === lang.code && (
                      <motion.div
                        className="absolute inset-0 rounded-2xl border-2 border-amber-300"
                        animate={{ opacity: [1, 0.3, 1], scale: [1, 1.02, 1] }}
                        transition={{ duration: 0.6, repeat: Infinity }}
                      />
                    )}
                  </motion.button>
                ))}
              </div>

              {/* Selected loading indicator */}
              <AnimatePresence>
                {selectedLang && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mt-8 flex items-center gap-3 text-white/60 text-sm"
                  >
                    <motion.div
                      className="w-4 h-4 rounded-full border-2 border-amber-400 border-t-transparent"
                      animate={{ rotate: 360 }}
                      transition={{ duration: 0.8, repeat: Infinity, ease: 'linear' }}
                    />
                    <span>Entering the experience...</span>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Scroll hint */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: showLanguages ? 0 : 1 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 pointer-events-none"
      >
        <motion.div
          className="w-px bg-gradient-to-b from-transparent via-amber-400/50 to-transparent"
          style={{ height: 48 }}
          animate={{ scaleY: [0, 1, 0], opacity: [0, 1, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        />
        <span className="text-white/20 text-xs tracking-[0.3em] uppercase">Scroll</span>
      </motion.div>
    </div>
  );
}
