import { motion, useScroll, useTransform } from 'framer-motion';
import { useRef, useState } from 'react';
import { Language, malaysiaStates, State, translations } from '../data/malaysiaData';
import { ChevronRight } from 'lucide-react';

interface FoodHighlightsProps {
  language: Language;
  onStateSelect: (state: State) => void;
}

const FEATURED = [
  { stateId: 'penang', foodName: 'Penang Assam Laksa', emoji: '🍲', img: '/images/laksa.jpg', tagEn: 'World Famous', tagMs: 'Terkenal Dunia', tagZh: '世界知名' },
  { stateId: 'selangor', foodName: 'Nasi Lemak', emoji: '🍚', img: '/images/nasi-lemak.jpg', tagEn: 'National Dish', tagMs: 'Hidangan Kebangsaan', tagZh: '国菜' },
  { stateId: 'penang', foodName: 'Char Kway Teow', emoji: '🍜', img: '/images/penang-food.jpg', tagEn: 'Street Food Icon', tagMs: 'Ikon Jalanan', tagZh: '街头经典' },
  { stateId: 'selangor', foodName: 'Bak Kut Teh', emoji: '🍖', img: '/images/bak-kut-teh.jpg', tagEn: 'Klang Legend', tagMs: 'Legenda Klang', tagZh: '巴生传奇' },
];

export default function FoodHighlights({ language, onStateSelect }: FoodHighlightsProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: containerRef, offset: ['start end', 'end start'] });
  const y = useTransform(scrollYProgress, [0, 1], [60, -60]);
  const t = translations[language];
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  return (
    <div ref={containerRef} className="relative py-20 px-4 overflow-hidden"
      style={{ background: 'linear-gradient(180deg, #FFF8F0 0%, #FFF3E0 100%)' }}>

      {/* Background decoration */}
      <motion.div style={{ y }} className="absolute inset-0 pointer-events-none">
        <div className="absolute top-10 right-10 w-72 h-72 rounded-full blur-3xl opacity-20"
          style={{ background: 'radial-gradient(circle, #F59E0B, transparent)' }} />
        <div className="absolute bottom-10 left-10 w-56 h-56 rounded-full blur-3xl opacity-15"
          style={{ background: 'radial-gradient(circle, #EF4444, transparent)' }} />
      </motion.div>

      {/* Batik pattern stripe */}
      <div className="absolute top-0 left-0 right-0 h-1 opacity-60"
        style={{ background: 'linear-gradient(90deg, #F59E0B, #EF4444, #2D6A4F, #2E86AB, #F59E0B)' }} />

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-14"
        >
          <p className="text-amber-600/70 text-xs font-medium tracking-[0.35em] uppercase mb-3">
            {language === 'zh' ? '必尝美食' : language === 'ms' ? 'Makanan Wajib Cuba' : 'Must Try'}
          </p>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
            {language === 'zh' ? '马来西亚' : language === 'ms' ? 'Makanan' : 'Iconic'}
            <span className="ml-2" style={{
              background: 'linear-gradient(135deg, #F59E0B, #EF4444)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}>
              {language === 'zh' ? '标志美食' : language === 'ms' ? 'Ikonik Malaysia' : 'Malaysian Flavours'}
            </span>
          </h2>
          <p className="text-gray-500 text-base max-w-xl mx-auto leading-relaxed">
            {language === 'zh'
              ? '从槟城到沙巴，每一道菜都讲述着一个关于文化、历史和热情的故事。'
              : language === 'ms'
              ? 'Dari Pulau Pinang ke Sabah, setiap hidangan menceritakan kisah budaya, sejarah dan semangat.'
              : 'From Penang to Sabah, every dish tells a story of culture, history, and passion.'
            }
          </p>
        </motion.div>

        {/* Featured food grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {FEATURED.map((item, i) => {
            const state = malaysiaStates.find(s => s.id === item.stateId);
            if (!state) return null;
            const food = state.foods.find(f => f.name === item.foodName);
            const tag = language === 'zh' ? item.tagZh : language === 'ms' ? item.tagMs : item.tagEn;
            const stateName = language === 'zh' ? state.nameZh : language === 'ms' ? state.nameMy : state.name;
            const foodName = food
              ? (language === 'zh' ? food.nameZh : language === 'ms' ? food.nameMy : food.name)
              : item.foodName;
            const foodDesc = food
              ? (language === 'zh' ? food.descriptionZh : language === 'ms' ? food.descriptionMy : food.description)
              : '';

            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.12, duration: 0.6 }}
                className="group relative rounded-3xl overflow-hidden cursor-pointer"
                style={{ boxShadow: '0 8px 30px rgba(0,0,0,0.1)' }}
                onMouseEnter={() => setHoveredIdx(i)}
                onMouseLeave={() => setHoveredIdx(null)}
                onClick={() => onStateSelect(state)}
                whileHover={{ y: -8, transition: { duration: 0.3 } }}
              >
                {/* Image */}
                <div className="relative h-56 overflow-hidden">
                  <img
                    src={item.img}
                    alt={item.foodName}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />

                  {/* Tag badge */}
                  <div className="absolute top-3 left-3">
                    <span className="px-2.5 py-1 rounded-full text-xs font-bold text-white"
                      style={{
                        background: `linear-gradient(135deg, ${state.color}, ${state.accentColor})`,
                        boxShadow: '0 2px 8px rgba(0,0,0,0.3)',
                      }}>
                      ✦ {tag}
                    </span>
                  </div>

                  {/* State name */}
                  <div className="absolute bottom-0 left-0 right-0 p-4">
                    <p className="text-amber-300/80 text-xs font-medium tracking-widest uppercase mb-1">
                      📍 {stateName}
                    </p>
                    <h3 className="text-white font-bold text-xl leading-tight">{foodName}</h3>
                  </div>
                </div>

                {/* Hover description */}
                <motion.div
                  className="bg-white p-4"
                  animate={{ height: hoveredIdx === i ? 'auto' : 0, opacity: hoveredIdx === i ? 1 : 0 }}
                  initial={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  style={{ overflow: 'hidden' }}
                >
                  <p className="text-gray-500 text-xs leading-relaxed line-clamp-3">{foodDesc}</p>
                  <div className="flex items-center gap-1 mt-2 text-amber-600 text-xs font-semibold">
                    <span>{language === 'zh' ? '探索更多' : language === 'ms' ? 'Terokai Lagi' : 'Explore More'}</span>
                    <ChevronRight size={12} />
                  </div>
                </motion.div>

                {/* Static bottom for non-hovered */}
                <div className={`bg-white px-4 py-3 ${hoveredIdx === i ? 'hidden' : 'block'}`}>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400 text-xs">{item.emoji} {foodName}</span>
                    <ChevronRight size={14} className="text-gray-300 group-hover:text-amber-500 transition-colors" />
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* View all button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
          className="text-center mt-12"
        >
          <button
            className="inline-flex items-center gap-2 px-8 py-3.5 rounded-full text-white font-semibold cursor-pointer"
            style={{
              background: 'linear-gradient(135deg, #F59E0B, #EF4444)',
              boxShadow: '0 8px 25px rgba(245,158,11,0.35)',
            }}
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          >
            {t.exploreMap}
            <ChevronRight size={16} />
          </button>
        </motion.div>
      </div>
    </div>
  );
}
