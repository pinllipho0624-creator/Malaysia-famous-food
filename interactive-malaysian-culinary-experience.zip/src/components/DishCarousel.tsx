import { motion } from 'framer-motion';
import { useRef, useState } from 'react';
import { Language, malaysiaStates } from '../data/malaysiaData';

interface DishCarouselProps {
  language: Language;
  onStateSelect: (stateId: string) => void;
}

const ALL_DISHES = malaysiaStates.flatMap(state =>
  state.foods.map(food => ({
    food,
    state,
  }))
);

const DISH_IMAGES: Record<string, string> = {
  'Char Kway Teow': '/images/penang-food.jpg',
  'Nasi Lemak': '/images/nasi-lemak.jpg',
  'Penang Assam Laksa': '/images/laksa.jpg',
  'Hinava': '/images/sabah-food.jpg',
  'Bak Kut Teh': '/images/bak-kut-teh.jpg',
};

const CARD_GRADIENTS = [
  'linear-gradient(135deg, #F59E0B, #EF4444)',
  'linear-gradient(135deg, #10B981, #3B82F6)',
  'linear-gradient(135deg, #8B5CF6, #EC4899)',
  'linear-gradient(135deg, #2E86AB, #1A7A4A)',
  'linear-gradient(135deg, #D4A017, #E8532A)',
  'linear-gradient(135deg, #2D6A4F, #6B3FA0)',
];

export default function DishCarousel({ language, onStateSelect }: DishCarouselProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const [scrollLeft, setScrollLeft] = useState(0);

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setStartX(e.pageX - (scrollRef.current?.offsetLeft || 0));
    setScrollLeft(scrollRef.current?.scrollLeft || 0);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || !scrollRef.current) return;
    e.preventDefault();
    const x = e.pageX - (scrollRef.current.offsetLeft);
    const walk = (x - startX) * 2;
    scrollRef.current.scrollLeft = scrollLeft - walk;
  };

  const handleMouseUp = () => setIsDragging(false);

  const sectionLabel = {
    en: 'All Dishes', ms: 'Semua Hidangan', zh: '全部菜肴',
  };

  const subtitleLabel = {
    en: 'Drag to explore · Click to discover', ms: 'Seret untuk terokai · Klik untuk temui', zh: '拖动探索 · 点击发现',
  };

  return (
    <div className="py-14 overflow-hidden"
      style={{ background: 'linear-gradient(180deg, #FEFEFE 0%, #FFF8F0 100%)' }}>

      {/* Header */}
      <div className="px-6 mb-8 max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <p className="text-amber-600/70 text-xs font-semibold tracking-[0.35em] uppercase mb-2">
            {subtitleLabel[language]}
          </p>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800">
            {sectionLabel[language]}
            <span className="ml-3 text-2xl font-normal text-gray-300">({ALL_DISHES.length})</span>
          </h2>
        </motion.div>
      </div>

      {/* Carousel */}
      <div
        ref={scrollRef}
        className="flex gap-4 px-6 overflow-x-auto pb-4 cursor-grab active:cursor-grabbing select-none"
        style={{ scrollbarWidth: 'none', msOverflowStyle: 'none', WebkitOverflowScrolling: 'touch' }}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        {ALL_DISHES.map(({ food, state }, i) => {
          const img = DISH_IMAGES[food.name];
          const gradient = CARD_GRADIENTS[i % CARD_GRADIENTS.length];
          const name = language === 'zh' ? food.nameZh : language === 'ms' ? food.nameMy : food.name;
          const stateName = language === 'zh' ? state.nameZh : language === 'ms' ? state.nameMy : state.name;

          return (
            <motion.div
              key={`${state.id}-${food.name}`}
              initial={{ opacity: 0, scale: 0.85 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: Math.min(i * 0.04, 0.5) }}
              onClick={() => onStateSelect(state.id)}
              className="flex-shrink-0 w-52 rounded-2xl overflow-hidden cursor-pointer group"
              style={{ boxShadow: '0 4px 20px rgba(0,0,0,0.1)' }}
              whileHover={{ y: -6, scale: 1.02, transition: { duration: 0.25 } }}
              whileTap={{ scale: 0.97 }}
            >
              {/* Card image */}
              <div className="relative h-36 overflow-hidden">
                {img ? (
                  <>
                    <img src={img} alt={name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                  </>
                ) : (
                  <div className="w-full h-full flex items-center justify-center" style={{ background: gradient }}>
                    <span className="text-5xl">{food.emoji}</span>
                  </div>
                )}
                {/* Halal indicator */}
                <div className="absolute top-2 right-2">
                  <span className={`w-5 h-5 rounded-full flex items-center justify-center text-xs ${
                    food.isHalal ? 'bg-emerald-500' : 'bg-gray-600'
                  }`}>
                    {food.isHalal ? '✓' : '✗'}
                  </span>
                </div>
              </div>

              {/* Card info */}
              <div className="p-3 bg-white">
                <p className="text-xs font-semibold mb-0.5"
                  style={{ color: state.color }}>
                  📍 {stateName}
                </p>
                <h4 className="text-gray-800 font-bold text-sm leading-tight mb-2 line-clamp-1">
                  {name}
                </h4>
                {/* Mini spice */}
                <div className="flex items-center gap-0.5">
                  {[1, 2, 3, 4, 5].map(n => (
                    <span key={n} className={`text-xs ${n <= food.spiceLevel ? 'opacity-100' : 'opacity-20'}`}>🌶</span>
                  ))}
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Scroll hint */}
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="flex justify-center mt-4 gap-2 items-center text-gray-300 text-xs"
      >
        <motion.div
          animate={{ x: [0, 8, 0] }}
          transition={{ duration: 1.5, repeat: Infinity }}
        >←</motion.div>
        <span>scroll to explore</span>
        <motion.div
          animate={{ x: [0, 8, 0] }}
          transition={{ duration: 1.5, repeat: Infinity }}
        >→</motion.div>
      </motion.div>
    </div>
  );
}
