import { motion } from 'framer-motion';
import { Language } from '../data/malaysiaData';

interface FooterProps {
  language: Language;
}

export default function Footer({ language }: FooterProps) {
  const labels = {
    en: { made: 'Made with', for: 'for food lovers everywhere', tagline: 'Discover Malaysia through food & culture', states: '13 States', dishes: '50+ Dishes', cultures: '3 Languages' },
    ms: { made: 'Dibuat dengan', for: 'untuk pencinta makanan di mana-mana', tagline: 'Temui Malaysia melalui makanan & budaya', states: '13 Negeri', dishes: '50+ Hidangan', cultures: '3 Bahasa' },
    zh: { made: '用', for: '为世界各地的美食爱好者制作', tagline: '通过美食与文化发现马来西亚', states: '13个州属', dishes: '50+道菜', cultures: '3种语言' },
  };

  const l = labels[language];

  const stats = [
    { value: l.states, icon: '🗺️' },
    { value: l.dishes, icon: '🍽️' },
    { value: l.cultures, icon: '🌍' },
  ];

  return (
    <footer className="relative overflow-hidden"
      style={{ background: 'linear-gradient(180deg, #1A0A00 0%, #0D0500 100%)' }}>

      {/* Top gradient border */}
      <div className="absolute top-0 left-0 right-0 h-px"
        style={{ background: 'linear-gradient(90deg, transparent, #F59E0B, #EF4444, #2D6A4F, transparent)' }} />

      {/* Background glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-48 rounded-full blur-3xl opacity-10"
        style={{ background: 'radial-gradient(circle, #F59E0B, transparent)' }} />

      <div className="max-w-5xl mx-auto px-6 py-16">
        {/* Logo & tagline */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <div className="text-4xl mb-4">🌺</div>
          <h3 className="text-3xl font-bold text-white mb-2">
            Rasa<span style={{
              background: 'linear-gradient(135deg, #FCD34D, #F97316)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}>Malaysia</span>
          </h3>
          <p className="text-gray-500 text-sm">{l.tagline}</p>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="flex justify-center gap-8 md:gap-16 mb-12"
        >
          {stats.map((stat, i) => (
            <div key={i} className="text-center">
              <div className="text-2xl mb-1">{stat.icon}</div>
              <div className="text-amber-400 font-bold text-lg">{stat.value}</div>
            </div>
          ))}
        </motion.div>

        {/* Malaysian flag colors strip */}
        <div className="flex h-1 rounded-full overflow-hidden mb-10 opacity-40">
          {['#EF4444', '#EF4444', '#FFFFFF', '#FFFFFF', '#EF4444', '#EF4444', '#FFFFFF', '#FFFFFF',
            '#EF4444', '#EF4444', '#FFFFFF', '#FFFFFF', '#EF4444', '#003399', '#003399',
          ].map((color, i) => (
            <div key={i} className="flex-1" style={{ background: color }} />
          ))}
        </div>

        {/* Food emojis */}
        <div className="flex justify-center gap-4 mb-10 text-2xl opacity-50">
          {['🍜', '🍛', '🌶️', '🥥', '🍲', '🥢', '🍚', '🌿'].map((e, i) => (
            <motion.span
              key={i}
              animate={{ y: [0, -6, 0] }}
              transition={{ duration: 2 + i * 0.2, repeat: Infinity, delay: i * 0.15 }}
            >
              {e}
            </motion.span>
          ))}
        </div>

        {/* Bottom */}
        <div className="text-center border-t border-white/5 pt-8">
          <p className="text-gray-600 text-sm">
            {l.made} ❤️ {l.for}
          </p>
          <p className="text-gray-700 text-xs mt-2">
            Malaysia · {new Date().getFullYear()} · Food & Culture Guide
          </p>
        </div>
      </div>
    </footer>
  );
}
