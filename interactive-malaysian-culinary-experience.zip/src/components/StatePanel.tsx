import { motion, AnimatePresence } from 'framer-motion';
import { X, MapPin, ChefHat, Leaf, Flame, Star, CheckCircle } from 'lucide-react';
import { State, Language, translations, Food } from '../data/malaysiaData';

interface StatePanelProps {
  state: State;
  language: Language;
  onClose: () => void;
}

// Mapping food names to local images
const FOOD_IMAGES: Record<string, string> = {
  'Char Kway Teow': '/images/penang-food.jpg',
  'Nasi Lemak': '/images/nasi-lemak.jpg',
  'Penang Assam Laksa': '/images/laksa.jpg',
  'Hinava': '/images/sabah-food.jpg',
  'Bak Kut Teh': '/images/bak-kut-teh.jpg',
};

const CARD_GRADIENTS = [
  { from: '#F59E0B', to: '#EF4444' },
  { from: '#EF4444', to: '#EC4899' },
  { from: '#10B981', to: '#3B82F6' },
  { from: '#8B5CF6', to: '#EC4899' },
  { from: '#F97316', to: '#FBBF24' },
];

function SpiceIndicator({ level }: { level: number }) {
  const spiceWords = ['None', 'Mild', 'Medium', 'Spicy', 'Very Spicy'];
  return (
    <div className="flex items-center gap-2">
      <div className="flex items-center gap-0.5">
        {[1, 2, 3, 4, 5].map(i => (
          <motion.div
            key={i}
            initial={{ scale: 0, rotate: -20 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ delay: 0.6 + i * 0.07, type: 'spring' }}
          >
            <Flame
              size={13}
              className={i <= level
                ? level >= 4 ? 'text-red-600 fill-red-600' : 'text-orange-500 fill-orange-400'
                : 'text-gray-200 fill-gray-100'}
            />
          </motion.div>
        ))}
      </div>
      <span className="text-xs text-gray-400 font-medium">{spiceWords[level] || 'None'}</span>
    </div>
  );
}

function FoodCard({ food, index, language, stateColor }: { food: Food; index: number; language: Language; stateColor: string }) {
  const img = FOOD_IMAGES[food.name];
  const gradient = CARD_GRADIENTS[index % CARD_GRADIENTS.length];
  const t = translations[language];

  const getName = () => language === 'zh' ? food.nameZh : language === 'ms' ? food.nameMy : food.name;
  const getDesc = () => language === 'zh' ? food.descriptionZh : language === 'ms' ? food.descriptionMy : food.description;

  return (
    <motion.div
      initial={{ opacity: 0, x: 30 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: 0.15 + index * 0.1, duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      className="group relative rounded-2xl overflow-hidden bg-white"
      style={{ boxShadow: '0 2px 20px rgba(0,0,0,0.06), 0 0 0 1px rgba(0,0,0,0.04)' }}
    >
      {/* Image/gradient header */}
      <div className="relative h-40 overflow-hidden">
        {img ? (
          <>
            <img
              src={img}
              alt={getName()}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-black/10 to-transparent" />
          </>
        ) : (
          <div
            className="w-full h-full flex items-center justify-center"
            style={{ background: `linear-gradient(135deg, ${gradient.from}, ${gradient.to})` }}
          >
            {/* Pattern overlay */}
            <div className="absolute inset-0 opacity-10" style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg width='30' height='30' viewBox='0 0 30 30' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='white'%3E%3Ccircle cx='15' cy='15' r='8' fill='none' stroke='white' stroke-width='1'/%3E%3C/g%3E%3C/svg%3E")`,
            }} />
            <motion.span
              className="text-6xl relative z-10 drop-shadow-lg"
              animate={{ y: [0, -6, 0], rotate: [-3, 3, -3] }}
              transition={{ duration: 3.5, repeat: Infinity }}
            >
              {food.emoji}
            </motion.span>
          </div>
        )}

        {/* Halal badge */}
        <div className="absolute top-3 right-3">
          <div className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold ${
            food.isHalal
              ? 'bg-emerald-500 text-white'
              : 'bg-gray-800/80 text-gray-300'
          }`}
            style={food.isHalal ? { boxShadow: '0 2px 8px rgba(16,185,129,0.4)' } : {}}>
            {food.isHalal
              ? <><CheckCircle size={10} className="fill-white" /> {t.halal}</>
              : <>{t.nonHalal}</>
            }
          </div>
        </div>

        {/* Food name overlay on image */}
        {img && (
          <div className="absolute bottom-3 left-3 right-3">
            <h4 className="text-white font-bold text-lg leading-tight drop-shadow-lg">
              {getName()}
            </h4>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-4">
        {!img && (
          <h4 className="font-bold text-gray-800 text-base mb-2 leading-tight">{getName()}</h4>
        )}
        <p className="text-gray-500 text-xs leading-relaxed mb-3" style={{
          display: '-webkit-box',
          WebkitLineClamp: 4,
          WebkitBoxOrient: 'vertical',
          overflow: 'hidden',
        }}>
          {getDesc()}
        </p>

        {/* Meta row */}
        <div className="flex items-center justify-between gap-2 pt-2 border-t border-gray-50">
          <SpiceIndicator level={food.spiceLevel} />
          <div className="flex items-center gap-1">
            <Star size={10} className="text-amber-400 fill-amber-400" />
            <span className="text-xs text-gray-400 font-medium">Must Try</span>
          </div>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-1 mt-2">
          {food.tags.slice(0, 4).map(tag => (
            <span
              key={tag}
              className="text-xs px-2 py-0.5 rounded-full font-medium"
              style={{
                background: `${stateColor}12`,
                color: stateColor,
                border: `1px solid ${stateColor}25`,
              }}
            >
              {tag}
            </span>
          ))}
        </div>
      </div>
    </motion.div>
  );
}

const regionLabel: Record<string, Record<Language, string>> = {
  'peninsular-west': { en: 'West Peninsular', ms: 'Semenanjung Barat', zh: '西马来西亚' },
  'peninsular-east': { en: 'East Peninsular', ms: 'Semenanjung Timur', zh: '东马（半岛）' },
  'borneo': { en: 'Borneo', ms: 'Borneo', zh: '婆罗洲' },
};

export default function StatePanel({ state, language, onClose }: StatePanelProps) {
  const t = translations[language];

  const getName = () => language === 'zh' ? state.nameZh : language === 'ms' ? state.nameMy : state.name;
  const getDesc = () => language === 'zh' ? state.descriptionZh : language === 'ms' ? state.descriptionMy : state.description;
  const getCulture = () => language === 'zh' ? state.culturalNoteZh : language === 'ms' ? state.culturalNoteMy : state.culturalNote;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-end md:items-stretch justify-end">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="absolute inset-0 bg-black/40 backdrop-blur-sm"
          onClick={onClose}
        />

        {/* Panel */}
        <motion.div
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ type: 'spring', damping: 30, stiffness: 320, mass: 0.9 }}
          className="relative z-10 w-full md:w-[500px] lg:w-[540px] flex flex-col"
          style={{
            height: window.innerWidth < 768 ? '92vh' : '100vh',
            background: '#FAFAF8',
            boxShadow: '-20px 0 80px rgba(0,0,0,0.2)',
          }}
        >
          {/* Hero / Header */}
          <div
            className="relative flex-shrink-0 overflow-hidden"
            style={{
              height: 220,
              background: `linear-gradient(145deg, ${state.color} 0%, ${state.accentColor} 60%, ${state.color}88 100%)`,
            }}
          >
            {/* Batik/wau pattern */}
            <div className="absolute inset-0 opacity-[0.08]" style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg width='50' height='50' viewBox='0 0 50 50' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='white'%3E%3Ccircle cx='25' cy='25' r='18' fill='none' stroke='white' stroke-width='2'/%3E%3Ccircle cx='25' cy='25' r='8' fill='none' stroke='white' stroke-width='1'/%3E%3Cline x1='7' y1='25' x2='43' y2='25' stroke='white' stroke-width='0.8'/%3E%3Cline x1='25' y1='7' x2='25' y2='43' stroke='white' stroke-width='0.8'/%3E%3C/g%3E%3C/svg%3E")`,
              backgroundSize: '50px 50px',
            }} />

            {/* Glow orbs */}
            <div className="absolute -top-10 -right-10 w-48 h-48 rounded-full blur-3xl bg-white/20" />
            <div className="absolute -bottom-8 -left-8 w-36 h-36 rounded-full blur-2xl bg-white/15" />

            {/* Big food emoji */}
            <motion.div
              className="absolute right-8 top-1/2 -translate-y-1/2 text-7xl opacity-25 select-none pointer-events-none"
              animate={{ y: [-6, 6, -6], rotate: [-5, 5, -5] }}
              transition={{ duration: 5, repeat: Infinity }}
            >
              {state.foods[0]?.emoji || '🍽️'}
            </motion.div>

            {/* Close */}
            <motion.button
              onClick={onClose}
              className="absolute top-4 right-4 w-9 h-9 rounded-full flex items-center justify-center cursor-pointer z-10"
              style={{ background: 'rgba(0,0,0,0.25)', border: '1px solid rgba(255,255,255,0.25)', backdropFilter: 'blur(10px)' }}
              whileHover={{ scale: 1.1, background: 'rgba(0,0,0,0.4)' }}
              whileTap={{ scale: 0.9 }}
            >
              <X size={16} className="text-white" />
            </motion.button>

            {/* State info */}
            <div className="absolute bottom-0 left-0 right-0 px-6 pb-5 pt-12"
              style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.35), transparent)' }}>
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.15, duration: 0.5 }}
              >
                <div className="flex items-center gap-1.5 mb-1.5">
                  <MapPin size={12} className="text-white/70 flex-shrink-0" />
                  <span className="text-white/70 text-xs tracking-widest uppercase font-medium">
                    {regionLabel[state.region]?.[language]} · {state.capital}
                  </span>
                </div>
                <h2 className="text-white font-black leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 2.8rem)' }}>
                  {getName()}
                </h2>
              </motion.div>
            </div>

            {/* Food count pill */}
            <motion.div
              initial={{ opacity: 0, scale: 0.7 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3, type: 'spring' }}
              className="absolute top-4 left-5 flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold text-white"
              style={{
                background: 'rgba(0,0,0,0.3)',
                backdropFilter: 'blur(10px)',
                border: '1px solid rgba(255,255,255,0.2)',
              }}
            >
              <ChefHat size={12} />
              {state.foods.length} {t.foods}
            </motion.div>
          </div>

          {/* Scrollable body */}
          <div className="flex-1 overflow-y-auto" style={{ overscrollBehavior: 'contain' }}>
            <div className="p-5 space-y-5">

              {/* Description */}
              <motion.div
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.25 }}
                className="p-4 rounded-2xl text-sm text-gray-600 leading-relaxed"
                style={{
                  background: `${state.color}0A`,
                  border: `1px solid ${state.color}18`,
                }}
              >
                {getDesc()}
              </motion.div>

              {/* Cultural Heritage */}
              <motion.div
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
              >
                <div className="flex items-center gap-2 mb-3">
                  <div
                    className="w-7 h-7 rounded-xl flex items-center justify-center"
                    style={{ background: `${state.color}15` }}
                  >
                    <Leaf size={14} style={{ color: state.color }} />
                  </div>
                  <h3 className="text-gray-700 font-bold text-sm uppercase tracking-widest">
                    {t.culture}
                  </h3>
                </div>
                <p className="text-gray-500 text-sm leading-relaxed pl-9 italic">
                  "{getCulture()}"
                </p>
              </motion.div>

              {/* Section divider */}
              <div className="relative flex items-center py-1">
                <div className="flex-1 h-px bg-gray-100" />
                <span className="mx-4 text-gray-300 text-xs tracking-[0.3em] uppercase font-medium flex-shrink-0">
                  ✦ {t.foods}
                </span>
                <div className="flex-1 h-px bg-gray-100" />
              </div>

              {/* Food cards */}
              <div className="space-y-4">
                {state.foods.map((food, i) => (
                  <FoodCard
                    key={food.name}
                    food={food}
                    index={i}
                    language={language}
                    stateColor={state.color}
                  />
                ))}
              </div>

              {/* Legend */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.8 }}
                className="flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-gray-400 pt-2 border-t border-gray-100"
              >
                <div className="flex items-center gap-1.5">
                  <Flame size={12} className="text-orange-400" />
                  <span>{t.spiceLevel}: 1-5</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 flex-shrink-0" />
                  <span>{t.halal} Certified</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-gray-400 flex-shrink-0" />
                  <span>{t.nonHalal}</span>
                </div>
              </motion.div>

              {/* Bottom spacer */}
              <div className="h-4" />
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
