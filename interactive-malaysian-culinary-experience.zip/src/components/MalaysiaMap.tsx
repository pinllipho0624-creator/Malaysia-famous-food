import { motion } from 'framer-motion';
import { useState } from 'react';
import { malaysiaStates, State, Language, translations } from '../data/malaysiaData';
import { MapPin } from 'lucide-react';

interface MalaysiaMapProps {
  language: Language;
  onStateSelect: (state: State) => void;
}

// More refined SVG paths for peninsular Malaysia
const peninsularPaths: Record<string, { d: string; labelX: number; labelY: number }> = {
  perlis: {
    d: 'M98 48 L118 46 L122 52 L120 65 L108 68 L96 62 L92 54 Z',
    labelX: 108, labelY: 57,
  },
  kedah: {
    d: 'M96 62 L108 68 L122 68 L130 82 L132 100 L125 118 L112 122 L98 118 L90 105 L86 85 L90 70 Z',
    labelX: 110, labelY: 96,
  },
  penang: {
    d: 'M74 92 L90 88 L94 100 L86 108 L74 104 Z',
    labelX: 84, labelY: 98,
  },
  perak: {
    d: 'M98 118 L112 122 L132 132 L138 155 L136 182 L124 196 L106 192 L96 178 L92 158 L96 138 Z',
    labelX: 116, labelY: 158,
  },
  kelantan: {
    d: 'M238 48 L278 44 L288 58 L293 80 L284 108 L258 115 L236 108 L224 90 L228 66 Z',
    labelX: 258, labelY: 80,
  },
  terengganu: {
    d: 'M258 115 L284 108 L293 80 L310 90 L316 115 L312 145 L292 158 L268 155 L252 140 Z',
    labelX: 284, labelY: 128,
  },
  pahang: {
    d: 'M174 130 L224 90 L236 108 L258 115 L252 140 L268 155 L260 178 L244 194 L216 202 L190 198 L168 185 L156 164 L162 144 Z',
    labelX: 213, labelY: 162,
  },
  selangor: {
    d: 'M96 178 L106 192 L124 196 L140 210 L145 228 L133 240 L116 235 L103 220 L96 200 Z',
    labelX: 118, labelY: 212,
  },
  'negeri-sembilan': {
    d: 'M124 196 L136 182 L152 196 L166 215 L160 238 L145 248 L133 240 L128 222 Z',
    labelX: 148, labelY: 224,
  },
  melaka: {
    d: 'M145 248 L160 238 L174 245 L177 260 L163 268 L148 264 Z',
    labelX: 161, labelY: 254,
  },
  johor: {
    d: 'M133 240 L145 248 L148 264 L163 268 L178 272 L190 280 L195 298 L180 314 L158 316 L138 308 L122 294 L118 272 L125 256 Z',
    labelX: 155, labelY: 282,
  },
};

const borneoPathsData: Record<string, { d: string; labelX: number; labelY: number }> = {
  sabah: {
    d: 'M462 130 L512 116 L548 123 L572 142 L576 168 L562 188 L543 204 L518 212 L490 214 L464 202 L448 180 L446 158 Z',
    labelX: 512, labelY: 168,
  },
  sarawak: {
    d: 'M362 198 L398 175 L428 170 L458 182 L464 202 L490 214 L518 212 L543 204 L558 225 L550 252 L526 272 L496 286 L462 292 L426 290 L395 280 L366 262 L350 238 L354 215 Z',
    labelX: 454, labelY: 244,
  },
};

const STATE_COLORS: Record<string, { fill: string; accent: string }> = {
  perlis: { fill: '#2980B9', accent: '#5DADE2' },
  kedah: { fill: '#16A085', accent: '#1ABC9C' },
  penang: { fill: '#E8532A', accent: '#FF8C5A' },
  perak: { fill: '#A0522D', accent: '#C4783A' },
  kelantan: { fill: '#2E86AB', accent: '#5BB8D4' },
  terengganu: { fill: '#1A7A4A', accent: '#2ECC71' },
  pahang: { fill: '#8E44AD', accent: '#BB6BD9' },
  selangor: { fill: '#E67E22', accent: '#F0A500' },
  'negeri-sembilan': { fill: '#C0392B', accent: '#E8645A' },
  melaka: { fill: '#922B21', accent: '#CD6155' },
  johor: { fill: '#B7950B', accent: '#F0C040' },
  sabah: { fill: '#2D6A4F', accent: '#52B788' },
  sarawak: { fill: '#6B3FA0', accent: '#9B6FD0' },
};

const getStateName = (id: string, lang: Language): string => {
  const state = malaysiaStates.find(s => s.id === id);
  if (!state) return id;
  return lang === 'zh' ? state.nameZh : lang === 'ms' ? state.nameMy : state.name;
};

interface MapRegionProps {
  pathData: Record<string, { d: string; labelX: number; labelY: number }>;
  hoveredState: string | null;
  language: Language;
  onHover: (id: string | null) => void;
  onSelect: (id: string) => void;
  fontSize?: number;
  smallLabels?: string[];
}

function MapRegion({ pathData, hoveredState, language, onHover, onSelect, fontSize = 7, smallLabels = [] }: MapRegionProps) {
  return (
    <>
      {Object.entries(pathData).map(([id, { d, labelX, labelY }]) => {
        const colors = STATE_COLORS[id];
        const isHovered = hoveredState === id;
        const state = malaysiaStates.find(s => s.id === id);
        const foodCount = state?.foods.length || 0;
        const fs = smallLabels.includes(id) ? fontSize - 1.5 : fontSize;

        return (
          <g key={id} className="cursor-pointer" onClick={() => onSelect(id)}>
            {/* Shadow/depth layer */}
            <path
              d={d}
              fill="rgba(0,0,0,0.15)"
              transform="translate(2,3)"
            />
            {/* Main state path */}
            <motion.path
              d={d}
              fill={isHovered ? colors.accent : colors.fill}
              stroke={isHovered ? 'white' : 'rgba(255,255,255,0.5)'}
              strokeWidth={isHovered ? 2 : 1}
              onMouseEnter={() => onHover(id)}
              onMouseLeave={() => onHover(null)}
              onTouchStart={() => onHover(id)}
              animate={{
                opacity: hoveredState && hoveredState !== id ? 0.75 : 1,
                filter: isHovered ? 'brightness(1.15) drop-shadow(0 0 8px rgba(255,255,255,0.4))' : 'brightness(1)',
              }}
              transition={{ duration: 0.2 }}
            />

            {/* Hover glow ring */}
            {isHovered && (
              <motion.path
                d={d}
                fill="none"
                stroke="rgba(255,255,255,0.6)"
                strokeWidth="3"
                initial={{ opacity: 0, scale: 1 }}
                animate={{ opacity: [0, 0.8, 0], scale: [1, 1.01, 1] }}
                transition={{ duration: 1, repeat: Infinity }}
              />
            )}

            {/* State label */}
            <text
              x={labelX}
              y={labelY - (isHovered ? 3 : 0)}
              textAnchor="middle"
              dominantBaseline="middle"
              fill="white"
              fontSize={fs}
              fontWeight="700"
              fontFamily="Inter, system-ui, sans-serif"
              style={{
                pointerEvents: 'none',
                textShadow: '0 1px 3px rgba(0,0,0,0.6)',
                transition: 'all 0.2s',
              }}
            >
              {getStateName(id, language)}
            </text>

            {/* Food count badge on hover */}
            {isHovered && (
              <g>
                <rect
                  x={labelX - 22}
                  y={labelY + 4}
                  width="44"
                  height="12"
                  rx="6"
                  fill="rgba(255,255,255,0.25)"
                />
                <text
                  x={labelX}
                  y={labelY + 10}
                  textAnchor="middle"
                  dominantBaseline="middle"
                  fill="white"
                  fontSize="5"
                  fontFamily="Inter, system-ui, sans-serif"
                  style={{ pointerEvents: 'none' }}
                >
                  {foodCount} dishes · tap
                </text>
              </g>
            )}
          </g>
        );
      })}
    </>
  );
}

export default function MalaysiaMap({ language, onStateSelect }: MalaysiaMapProps) {
  const [hoveredState, setHoveredState] = useState<string | null>(null);
  const t = translations[language];

  const handleStateClick = (stateId: string) => {
    const state = malaysiaStates.find(s => s.id === stateId);
    if (state) onStateSelect(state);
  };

  return (
    <div
      className="relative min-h-screen overflow-hidden"
      style={{ background: 'linear-gradient(160deg, #FFFCF5 0%, #FEF9EE 40%, #F0FDF8 80%, #EFF8FF 100%)' }}
    >
      {/* Decorative batik rings */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[...Array(4)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full"
            style={{
              width: 180 + i * 160,
              height: 180 + i * 160,
              right: '-5%',
              top: '10%',
              border: `1px solid rgba(245,158,11,${0.06 - i * 0.01})`,
              transform: 'translate(30%, 0)',
            }}
            animate={{ rotate: i % 2 === 0 ? 360 : -360 }}
            transition={{ duration: 35 + i * 8, repeat: Infinity, ease: 'linear' }}
          />
        ))}
        {/* Tropical color blobs */}
        <div className="absolute -top-20 -left-20 w-96 h-96 rounded-full blur-3xl opacity-15"
          style={{ background: 'radial-gradient(circle, #FCD34D, transparent)' }} />
        <div className="absolute -bottom-20 -right-20 w-96 h-96 rounded-full blur-3xl opacity-10"
          style={{ background: 'radial-gradient(circle, #34D399, transparent)' }} />
      </div>

      {/* Section header */}
      <div className="relative z-10 pt-10 pb-6 px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full mb-4 text-xs font-semibold tracking-widest uppercase"
            style={{ background: 'rgba(245,158,11,0.1)', color: '#B45309', border: '1px solid rgba(245,158,11,0.2)' }}>
            <MapPin size={12} />
            {language === 'zh' ? '互动美食地图' : language === 'ms' ? 'Peta Makanan Interaktif' : 'Interactive Food Map'}
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-2">
            {language === 'zh' ? '探索' : language === 'ms' ? 'Terokai' : 'Explore the'}
            <span className="ml-2" style={{
              background: 'linear-gradient(135deg, #F59E0B, #EF4444)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}>
              {language === 'zh' ? '马来西亚13州' : language === 'ms' ? '13 Negeri Malaysia' : '13 States of Malaysia'}
            </span>
          </h2>
          <p className="text-gray-400 text-sm">{t.tapState}</p>
        </motion.div>
      </div>

      {/* Maps grid */}
      <div className="relative z-10 flex flex-col xl:flex-row items-center justify-center gap-8 px-4 pb-10">

        {/* Peninsular Malaysia */}
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="w-full max-w-lg xl:max-w-md"
        >
          <div className="text-center mb-3">
            <span className="inline-block text-xs font-bold tracking-widest text-gray-400 uppercase bg-white/60 px-3 py-1 rounded-full backdrop-blur-sm">
              {language === 'zh' ? '🇲🇾 西马来西亚（半岛）' : language === 'ms' ? '🇲🇾 Semenanjung Malaysia' : '🇲🇾 Peninsular Malaysia'}
            </span>
          </div>
          <div
            className="relative rounded-3xl overflow-hidden p-4"
            style={{
              background: 'rgba(255,255,255,0.7)',
              backdropFilter: 'blur(20px)',
              boxShadow: '0 20px 60px rgba(0,0,0,0.08), inset 0 0 0 1px rgba(255,255,255,0.8)',
            }}
          >
            <svg
              viewBox="70 40 285 295"
              className="w-full"
              style={{ height: 'auto', maxHeight: '480px' }}
            >
              <defs>
                <radialGradient id="seaWest" cx="50%" cy="60%" r="60%">
                  <stop offset="0%" stopColor="#BAE6FD" stopOpacity="0.5" />
                  <stop offset="100%" stopColor="#7DD3FC" stopOpacity="0.15" />
                </radialGradient>
                <filter id="glowEffect">
                  <feGaussianBlur stdDeviation="2" result="blur" />
                  <feMerge>
                    <feMergeNode in="blur" />
                    <feMergeNode in="SourceGraphic" />
                  </feMerge>
                </filter>
              </defs>

              {/* Sea background */}
              <rect x="70" y="40" width="285" height="295" fill="url(#seaWest)" rx="18" />

              {/* Wave decoration */}
              {[0, 1, 2].map(i => (
                <ellipse key={i} cx={120 + i * 30} cy={340 + i * 5} rx="20" ry="4"
                  fill="rgba(186,230,253,0.3)" />
              ))}

              <MapRegion
                pathData={peninsularPaths}
                hoveredState={hoveredState}
                language={language}
                onHover={setHoveredState}
                onSelect={handleStateClick}
                fontSize={7}
                smallLabels={['penang', 'melaka', 'perlis', 'negeri-sembilan']}
              />
            </svg>
          </div>
        </motion.div>

        {/* East Malaysia */}
        <motion.div
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="w-full max-w-lg xl:max-w-md"
        >
          <div className="text-center mb-3">
            <span className="inline-block text-xs font-bold tracking-widest text-gray-400 uppercase bg-white/60 px-3 py-1 rounded-full backdrop-blur-sm">
              {language === 'zh' ? '🌴 东马来西亚（婆罗洲）' : language === 'ms' ? '🌴 Malaysia Timur (Borneo)' : '🌴 East Malaysia (Borneo)'}
            </span>
          </div>
          <div
            className="relative rounded-3xl overflow-hidden p-4"
            style={{
              background: 'rgba(255,255,255,0.7)',
              backdropFilter: 'blur(20px)',
              boxShadow: '0 20px 60px rgba(0,0,0,0.08), inset 0 0 0 1px rgba(255,255,255,0.8)',
            }}
          >
            <svg
              viewBox="340 108 250 200"
              className="w-full"
              style={{ height: 'auto', maxHeight: '380px' }}
            >
              <defs>
                <radialGradient id="seaEast" cx="50%" cy="50%" r="60%">
                  <stop offset="0%" stopColor="#A7F3D0" stopOpacity="0.3" />
                  <stop offset="100%" stopColor="#6EE7B7" stopOpacity="0.1" />
                </radialGradient>
              </defs>

              <rect x="340" y="108" width="250" height="200" fill="url(#seaEast)" rx="18" />

              <MapRegion
                pathData={borneoPathsData}
                hoveredState={hoveredState}
                language={language}
                onHover={setHoveredState}
                onSelect={handleStateClick}
                fontSize={11}
              />

              {/* Borneo rainforest icon */}
              <text x="380" y="290" fontSize="18" opacity="0.25">🌴</text>
              <text x="565" y="135" fontSize="14" opacity="0.2">🦅</text>
            </svg>
          </div>
        </motion.div>
      </div>

      {/* Quick-select chips */}
      <div className="relative z-10 px-4 pb-12">
        <div className="max-w-3xl mx-auto text-center">
          <p className="text-xs text-gray-400 mb-4 tracking-widest uppercase font-medium">
            {language === 'zh' ? '快速选择州属' : language === 'ms' ? 'Pilih Negeri Terus' : 'Quick Select a State'}
          </p>
          <div className="flex flex-wrap justify-center gap-2">
            {malaysiaStates.map((state, i) => {
              const name = language === 'zh' ? state.nameZh : language === 'ms' ? state.nameMy : state.name;
              const isHov = hoveredState === state.id;
              return (
                <motion.button
                  key={state.id}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.6 + i * 0.04 }}
                  onClick={() => onStateSelect(state)}
                  onMouseEnter={() => setHoveredState(state.id)}
                  onMouseLeave={() => setHoveredState(null)}
                  className="group relative px-4 py-2 rounded-full text-sm font-medium cursor-pointer transition-all duration-200"
                  style={{
                    background: isHov ? `linear-gradient(135deg, ${state.color}, ${state.accentColor})` : 'rgba(255,255,255,0.8)',
                    color: isHov ? 'white' : state.color,
                    border: `1.5px solid ${state.color}40`,
                    boxShadow: isHov ? `0 4px 15px ${state.color}40` : '0 2px 8px rgba(0,0,0,0.05)',
                    backdropFilter: 'blur(10px)',
                  }}
                  whileHover={{ scale: 1.06, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {name}
                  <span className="ml-1.5 opacity-60 text-xs">
                    {state.foods.length}🍽️
                  </span>
                </motion.button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Floating decorative food emojis */}
      {[
        { emoji: '🌶️', x: '5%', y: '30%' },
        { emoji: '🥥', x: '90%', y: '20%' },
        { emoji: '🍜', x: '8%', y: '65%' },
        { emoji: '🌿', x: '88%', y: '70%' },
        { emoji: '🍛', x: '2%', y: '50%' },
        { emoji: '🥢', x: '94%', y: '50%' },
      ].map(({ emoji, x, y }, i) => (
        <motion.div
          key={i}
          className="absolute text-3xl pointer-events-none select-none"
          style={{ left: x, top: y, opacity: 0.15 }}
          animate={{
            y: [0, -20, 0],
            rotate: [-8, 8, -8],
            scale: [1, 1.1, 1],
          }}
          transition={{
            duration: 4 + i * 0.6,
            repeat: Infinity,
            delay: i * 0.7,
            ease: 'easeInOut',
          }}
        >
          {emoji}
        </motion.div>
      ))}
    </div>
  );
}
