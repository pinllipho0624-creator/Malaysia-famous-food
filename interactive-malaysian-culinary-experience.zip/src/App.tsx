import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import WelcomeScreen from './components/WelcomeScreen';
import MalaysiaMap from './components/MalaysiaMap';
import StatePanel from './components/StatePanel';
import Navbar from './components/Navbar';
import FoodHighlights from './components/FoodHighlights';
import DishCarousel from './components/DishCarousel';
import Footer from './components/Footer';
import { Language, State, malaysiaStates } from './data/malaysiaData';

type AppStage = 'welcome' | 'map';

export default function App() {
  const [stage, setStage] = useState<AppStage>('welcome');
  const [language, setLanguage] = useState<Language>('en');
  const [selectedState, setSelectedState] = useState<State | null>(null);

  const handleLanguageSelect = (lang: Language) => {
    setLanguage(lang);
    setStage('map');
  };

  const handleStateSelect = (state: State) => {
    setSelectedState(state);
  };

  const handleClosePanel = () => {
    setSelectedState(null);
  };

  const handleLogoClick = () => {
    setSelectedState(null);
    setStage('welcome');
  };

  return (
    <div className="min-h-screen font-sans antialiased" style={{ fontFamily: "'Inter', 'Segoe UI', system-ui, sans-serif" }}>
      <AnimatePresence mode="wait">
        {stage === 'welcome' ? (
          <motion.div
            key="welcome"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            transition={{ duration: 0.8 }}
          >
            <WelcomeScreen onLanguageSelect={handleLanguageSelect} />
          </motion.div>
        ) : (
          <motion.div
            key="main"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.6 }}
          >
            {/* Navbar */}
            <Navbar
              language={language}
              onLanguageChange={setLanguage}
              onLogoClick={handleLogoClick}
            />

            {/* Main content with top padding for navbar */}
            <div className="pt-20">
              {/* Map section */}
              <MalaysiaMap
                language={language}
                onStateSelect={handleStateSelect}
              />

              {/* Food highlights section */}
              <FoodHighlights
                language={language}
                onStateSelect={handleStateSelect}
              />

              {/* All dishes carousel */}
              <DishCarousel
                language={language}
                onStateSelect={(stateId) => {
                  const state = malaysiaStates.find(s => s.id === stateId);
                  if (state) handleStateSelect(state);
                }}
              />

              {/* Stats bar */}
              <StatsBar language={language} />

              {/* Culture banner */}
              <CultureBanner language={language} />

              {/* Footer */}
              <Footer language={language} />
            </div>

            {/* State detail panel */}
            <AnimatePresence>
              {selectedState && (
                <StatePanel
                  key={selectedState.id}
                  state={selectedState}
                  language={language}
                  onClose={handleClosePanel}
                />
              )}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function StatsBar({ language }: { language: Language }) {
  const stats = [
    { value: '13', labelEn: 'States', labelMs: 'Negeri', labelZh: '州属', emoji: '🗺️' },
    { value: '50+', labelEn: 'Dishes', labelMs: 'Hidangan', labelZh: '道菜', emoji: '🍽️' },
    { value: '3', labelEn: 'Languages', labelMs: 'Bahasa', labelZh: '种语言', emoji: '🌍' },
    { value: '∞', labelEn: 'Flavours', labelMs: 'Perisa', labelZh: '种风味', emoji: '✨' },
  ];

  const getLabel = (s: typeof stats[0]) =>
    language === 'zh' ? s.value + s.labelZh : language === 'ms' ? s.labelMs : s.labelEn;

  return (
    <div className="py-8 px-4" style={{ background: 'linear-gradient(135deg, #1A0500, #0D0300)' }}>
      <div className="max-w-4xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="text-center py-4 px-2 rounded-2xl"
            style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.06)' }}
          >
            <div className="text-2xl mb-1">{stat.emoji}</div>
            <div className="text-3xl font-black text-white mb-0.5"
              style={{
                background: 'linear-gradient(135deg, #FCD34D, #F97316)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
              }}>
              {stat.value}
            </div>
            <div className="text-gray-500 text-xs font-medium uppercase tracking-widest">
              {getLabel(stat)}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

function CultureBanner({ language }: { language: Language }) {
  const content = {
    en: {
      title: 'A Nation of Many Flavours',
      subtitle: 'Where Three Great Civilisations Meet',
      desc: 'Malaysian cuisine is the beautiful result of centuries of cultural exchange between the Malay, Chinese, Indian, and indigenous communities — each contributing unique spices, techniques, and traditions to create one of the world\'s most diverse food cultures.',
      items: [
        { icon: '🕌', title: 'Malay Heritage', desc: 'Rooted in coconut, pandan, and aromatic spices. Dishes like Nasi Lemak and Rendang are culinary poetry.' },
        { icon: '🏮', title: 'Chinese Tradition', desc: 'Wok mastery, dim sum artistry, and noodle craft. Penang\'s hawker stalls are living heritage.' },
        { icon: '🪔', title: 'Indian Soul', desc: 'Banana leaf feasts, mamak culture, and the magic of curry. Tamil and Punjabi flavours woven into daily life.' },
        { icon: '🌿', title: 'Indigenous Wisdom', desc: 'Borneo\'s Kadazan, Iban, and Orang Asli share forest herbs, bamboo cooking, and ancient food traditions.' },
      ],
    },
    ms: {
      title: 'Sebuah Negara dengan Pelbagai Rasa',
      subtitle: 'Di Mana Tiga Tamadun Besar Bertemu',
      desc: 'Masakan Malaysia adalah hasil indah daripada berabad-abad pertukaran budaya antara komuniti Melayu, Cina, India dan orang asli — masing-masing menyumbang rempah, teknik dan tradisi yang unik.',
      items: [
        { icon: '🕌', title: 'Warisan Melayu', desc: 'Berakar dengan kelapa, pandan dan rempah aromatik. Hidangan seperti Nasi Lemak dan Rendang adalah puisi masakan.' },
        { icon: '🏮', title: 'Tradisi Cina', desc: 'Keahlian wok, seni dim sum dan kraf mi. Gerai penjaja Pulau Pinang adalah warisan yang hidup.' },
        { icon: '🪔', title: 'Jiwa India', desc: 'Pesta daun pisang, budaya mamak dan keajaiban kari. Rasa Tamil dan Punjabi ditenun ke dalam kehidupan harian.' },
        { icon: '🌿', title: 'Kebijaksanaan Orang Asli', desc: 'Kadazan, Iban dan Orang Asli Borneo berkongsi herba hutan, masakan buluh dan tradisi makanan purba.' },
      ],
    },
    zh: {
      title: '多种风味的国度',
      subtitle: '三大文明的交汇之地',
      desc: '马来西亚美食是马来、华人、印度和原住民社区数百年文化交流的美丽结晶——每个族群都贡献了独特的香料、技术和传统，创造出世界上最多元的饮食文化之一。',
      items: [
        { icon: '🕌', title: '马来传统', desc: '以椰子、班兰和芳香香料为根基。椰浆饭和仁当是饮食诗篇。' },
        { icon: '🏮', title: '华人传统', desc: '镬气掌控、点心艺术和面食工艺。槟城小贩摊是活态遗产。' },
        { icon: '🪔', title: '印度灵魂', desc: '香蕉叶盛宴、印裔穆斯林文化和咖喱魔力。泰米尔和旁遮普风味融入日常生活。' },
        { icon: '🌿', title: '原住民智慧', desc: '婆罗洲的卡达山、伊班族和原住民分享森林草药、竹制烹饪和古老饮食传统。' },
      ],
    },
  };

  const c = content[language];

  return (
    <div className="relative py-20 px-4 overflow-hidden"
      style={{ background: 'linear-gradient(135deg, #0D1117 0%, #1A0A00 50%, #0D1117 100%)' }}>

      {/* Animated batik rings */}
      {[...Array(3)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full pointer-events-none"
          style={{
            width: 300 + i * 200,
            height: 300 + i * 200,
            left: '50%',
            top: '50%',
            transform: 'translate(-50%, -50%)',
            border: `1px solid rgba(245,158,11,${0.08 - i * 0.02})`,
          }}
          animate={{ rotate: i % 2 === 0 ? 360 : -360 }}
          transition={{ duration: 40 + i * 10, repeat: Infinity, ease: 'linear' }}
        />
      ))}

      {/* Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] rounded-full blur-3xl opacity-10"
        style={{ background: 'radial-gradient(ellipse, #F59E0B, transparent)' }} />

      <div className="max-w-5xl mx-auto relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-14"
        >
          <p className="text-amber-400/60 text-xs font-medium tracking-[0.35em] uppercase mb-3">
            {c.subtitle}
          </p>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-5">
            {c.title}
          </h2>
          <p className="text-gray-400 text-base leading-relaxed max-w-2xl mx-auto">
            {c.desc}
          </p>
        </motion.div>

        {/* Culture cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {c.items.map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="relative p-5 rounded-2xl group cursor-default"
              style={{
                background: 'rgba(255,255,255,0.04)',
                border: '1px solid rgba(255,255,255,0.08)',
                backdropFilter: 'blur(10px)',
              }}
              whileHover={{
                background: 'rgba(245,158,11,0.08)',
                borderColor: 'rgba(245,158,11,0.2)',
                y: -4,
                transition: { duration: 0.2 }
              }}
            >
              <div className="text-3xl mb-3">{item.icon}</div>
              <h4 className="text-white font-semibold text-base mb-2">{item.title}</h4>
              <p className="text-gray-500 text-xs leading-relaxed group-hover:text-gray-400 transition-colors">
                {item.desc}
              </p>

              {/* Hover glow corner */}
              <div className="absolute top-0 right-0 w-16 h-16 rounded-full blur-2xl opacity-0 group-hover:opacity-30 transition-opacity"
                style={{ background: '#F59E0B', transform: 'translate(30%, -30%)' }} />
            </motion.div>
          ))}
        </div>

        {/* Bottom decorative line */}
        <motion.div
          initial={{ scaleX: 0 }}
          whileInView={{ scaleX: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="mt-14 h-px rounded-full"
          style={{ background: 'linear-gradient(90deg, transparent, #F59E0B40, #EF444440, transparent)' }}
        />
      </div>
    </div>
  );
}
